# -*- coding: utf-8 -*-
import os, warnings, time
import torch, torchaudio
import numpy as np
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier, VotingClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
from speechbrain.inference.classifiers import EncoderClassifier
from speechbrain.utils.fetching import LocalStrategy

warnings.filterwarnings("ignore")

# ============================================================
#  AYARLAR
# ============================================================
ANA_DIR   = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
GIRLS_DIR = os.path.join(ANA_DIR, "girls")
MODEL_DIR = os.path.join(ANA_DIR, "ses_egitimi", "pkl_modelleri")
EMB_CACHE = os.path.join(MODEL_DIR, "embeddingler_cache.npy")
os.makedirs(MODEL_DIR, exist_ok=True)

HOLDOUT_VLOG = "vlog3"

# Augmentation katlari: az verili kizlar daha cok kopyalanir
AUG_KATI = {
    'lidya':  3,   # en az veri
    'hilal':  3,   # karisan
    'sueda':  2,
    'mina':   2,
    'esin':   1,   # zaten cok veri var
    'zoktay': 1,
}

GUVEN_ESIGI = 0.50

# ============================================================
#  YARDIMCI
# ============================================================
def sinyal_yukle(yol):
    sinyal, fs = torchaudio.load(yol)
    if fs != 16000:
        sinyal = torchaudio.transforms.Resample(fs, 16000)(sinyal)
    if sinyal.shape[0] > 1:
        sinyal = torch.mean(sinyal, dim=0, keepdim=True)
    return sinyal

def emb_augment(emb, n):
    """Embedding vektorunu n kez hafifce pertürbe ederek yeni ornekler uret."""
    sonuclar = []
    for _ in range(n):
        gurultu = np.random.randn(len(emb)) * 0.015
        sonuclar.append(emb + gurultu)
    return sonuclar

# ============================================================
#  1. EMBEDDING CACHE (v9'dan kalani tekrar kullanir)
# ============================================================
def embedding_cache_olustur(ekstrakter):
    print("\n[1/4] Embedding cache kontrol ediliyor...")
    tum_dosyalar = []
    for kiz in os.listdir(GIRLS_DIR):
        kiz_yolu = os.path.join(GIRLS_DIR, kiz)
        if not os.path.isdir(kiz_yolu): continue
        for f in os.listdir(kiz_yolu):
            if f.endswith(".wav"):
                tum_dosyalar.append((kiz, os.path.join(kiz_yolu, f)))

    if os.path.exists(EMB_CACHE):
        cache = np.load(EMB_CACHE, allow_pickle=True).item()
        eksik = [d for d in tum_dosyalar if d[1] not in cache]
        if not eksik:
            print(f"  Cache hazir: {len(cache)} embedding (yeni hesaplama yok).")
            return cache, tum_dosyalar
        print(f"  {len(eksik)} yeni dosya isleniyor...")
    else:
        cache = {}
        eksik = tum_dosyalar
        print(f"  {len(eksik)} dosya isleniyor...")

    for i, (kiz, yol) in enumerate(eksik):
        try:
            sinyal = sinyal_yukle(yol)
            emb = ekstrakter.encode_batch(sinyal).squeeze().detach().numpy()
            cache[yol] = emb
        except:
            pass
        if (i+1) % 50 == 0:
            print(f"  {i+1}/{len(eksik)} islendi...")

    np.save(EMB_CACHE, cache)
    print(f"  Cache kaydedildi: {len(cache)} embedding.")
    return cache, tum_dosyalar

# ============================================================
#  2. VERI AYIRIMI + AKILLI AUGMENTATION
# ============================================================
def veri_ayir(tum_dosyalar, cache):
    from collections import Counter
    print(f"\n[2/4] Veri ayriliyor + augmentation uygulanıyor...")

    X_train, y_train = [], []
    X_test,  y_test  = [], []

    for kiz, yol in tum_dosyalar:
        if yol not in cache: continue
        emb = cache[yol]

        if HOLDOUT_VLOG in os.path.basename(yol):
            X_test.append(emb)
            y_test.append(kiz)
        else:
            X_train.append(emb)
            y_train.append(kiz)
            # Augmentation: kize gore farkli kat
            kat = AUG_KATI.get(kiz, 1)
            if kat > 1:
                for aug_emb in emb_augment(emb, kat - 1):
                    X_train.append(aug_emb)
                    y_train.append(kiz)

    X_train = np.array(X_train)
    X_test  = np.array(X_test)
    le = LabelEncoder()
    y_train_enc = le.fit_transform(y_train)
    y_test_enc  = le.transform(y_test)

    print("  EGITIM dagilimi (augmentation sonrasi):")
    for kiz, adet in sorted(Counter(y_train).items()):
        print(f"    {kiz:<10}: {adet}")
    print(f"  TEST ({HOLDOUT_VLOG}): {len(y_test)} ornek")
    return X_train, X_test, y_train_enc, y_test_enc, le

# ============================================================
#  3. ENSEMBLE MODEL (SVM + LR + GBM oylama)
# ============================================================
def model_egit(X_train, y_train):
    print("\n[3/4] Ensemble model egitiliyor (SVM + LR + GBM)...")
    scaler = StandardScaler()
    X_sc = scaler.fit_transform(X_train)

    svm = SVC(kernel='rbf', C=10, gamma='scale',
              class_weight='balanced', probability=True, random_state=42)

    lr = LogisticRegression(max_iter=2000, class_weight='balanced',
                            C=0.1, random_state=42)

    gbm = GradientBoostingClassifier(n_estimators=200, learning_rate=0.05,
                                     max_depth=4, random_state=42)

    ensemble = VotingClassifier(
        estimators=[('svm', svm), ('lr', lr), ('gbm', gbm)],
        voting='soft'
    )
    ensemble.fit(X_sc, y_train)
    print("  Tamamlandi.")
    return scaler, ensemble

# ============================================================
#  4. DEGERLENDIRME + CONFUSION MATRIX
# ============================================================
def degerlendir(scaler, model, le, X_test, y_test_enc):
    print("\n[4/4] Degerlendirme yapiliyor...")
    X_sc = scaler.transform(X_test)
    ihtimaller = model.predict_proba(X_sc)

    y_pred_esikli, y_ger_esikli, belirsiz = [], [], 0
    for i, olasilik in enumerate(ihtimaller):
        if np.max(olasilik) >= GUVEN_ESIGI:
            y_pred_esikli.append(np.argmax(olasilik))
            y_ger_esikli.append(y_test_enc[i])
        else:
            belirsiz += 1

    y_pred_esiksiz = np.argmax(ihtimaller, axis=1)
    acc_esiksiz = accuracy_score(y_test_enc, y_pred_esiksiz) * 100
    acc_esikli  = accuracy_score(y_ger_esikli, y_pred_esikli) * 100 if y_pred_esikli else 0

    print("\n" + "="*55)
    print("  V10 SONUCLARI")
    print("="*55)
    print(f"  Test seti          : {HOLDOUT_VLOG}")
    print(f"  Toplam dosya       : {len(y_test_enc)}")
    print(f"  Belirsiz           : {belirsiz}")
    print(f"  Accuracy (esiksiz) : %{acc_esiksiz:.1f}  <- GERCEK")
    print(f"  Accuracy (esikli)  : %{acc_esikli:.1f}  <- Filtreli")
    print(f"\n  V9 ile karsilastirma: %78.5 -> %{acc_esiksiz:.1f}")
    print("="*55)
    print(classification_report(y_test_enc, y_pred_esiksiz, target_names=le.classes_))

    # Confusion matrix
    cm = confusion_matrix(y_test_enc, y_pred_esiksiz, labels=range(len(le.classes_)))
    fig, ax = plt.subplots(figsize=(8, 6))
    ConfusionMatrixDisplay(cm, display_labels=le.classes_).plot(
        ax=ax, cmap='Blues', colorbar=False)
    ax.set_title(
        f'V10 - {HOLDOUT_VLOG} holdout | Ensemble: SVM+LR+GBM\n'
        f'Esiksiz: %{acc_esiksiz:.1f}  |  Esikli: %{acc_esikli:.1f}'
    )
    plt.tight_layout()
    cm_yolu = os.path.join(MODEL_DIR, "v10_confusion_matrix.png")
    plt.savefig(cm_yolu, dpi=150)
    plt.close()
    print(f"  Confusion matrix: {cm_yolu}")
    return acc_esiksiz, acc_esikli

# ============================================================
#  ANA AKIS
# ============================================================
if __name__ == "__main__":
    print("="*55)
    print("  MANIFEST SES TANIMA - V10")
    print("  V9'dan iyilestirmeler:")
    print("  - Ensemble: SVM + LR + GBM oylama")
    print("  - Akilli augmentation (kize gore 1x-3x)")
    print("  - Embedding cache tekrar kullaniliyor")
    print("="*55)
    t0 = time.time()

    print("\nSpeechBrain yukleniyor...")
    ekstrakter = EncoderClassifier.from_hparams(
        source="speechbrain/spkrec-ecapa-voxceleb",
        savedir="C:/tmp/speechbrain",
        local_strategy=LocalStrategy.COPY
    )

    cache, tum = embedding_cache_olustur(ekstrakter)
    X_tr, X_te, y_tr, y_te, le = veri_ayir(tum, cache)
    scaler, model = model_egit(X_tr, y_tr)
    degerlendir(scaler, model, le, X_te, y_te)

    joblib.dump((scaler, model), os.path.join(MODEL_DIR, "kizlar_ses_modeli_v10.pkl"))
    joblib.dump(le, os.path.join(MODEL_DIR, "isim_tercumani_v10.pkl"))

    print(f"\n  Toplam sure: {round(time.time()-t0, 1)} sn")
    print("="*55)
