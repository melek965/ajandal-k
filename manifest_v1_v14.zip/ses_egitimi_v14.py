# -*- coding: utf-8 -*-
"""
V14: L2-normalize + multi-window TTA cache + ogrenilen per-class threshold (nested CV).

V13 ile farklar:
  1. StandardScaler kaldirildi -> L2-normalize (ECAPA cosine icin tasarlanmis)
  2. embeddingler_tta_cache.npy kullanilir (multi-window mean)
  3. PER_CLASS_THRESHOLD heuristik degil: nested CV ile ogrenilir
     - Outer fold: test=her vlog (4-fold)
     - Inner LOO: training vloglardan biri val, OOF probs
     - Coordinate descent: macro-F1 maks. esikleri bul
     - Final: 3 vlog uzerinde tam egit, ogrenilen esiklerle outer test'e uygula

Arguman: --cache normal|tta  (default tta)
"""
import os, re, time, sys, warnings
import numpy as np
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (accuracy_score, classification_report,
                              confusion_matrix, ConfusionMatrixDisplay,
                              f1_score, precision_recall_fscore_support)

warnings.filterwarnings("ignore")

# ============================================================
HERE = os.path.dirname(os.path.abspath(__file__))
ANA_DIR = os.path.abspath(os.path.join(HERE, "..", ".."))
GIRLS_DIR = os.path.join(ANA_DIR, "girls")
MODEL_DIR = os.path.join(ANA_DIR, "ses_egitimi", "pkl_modelleri")
CACHE_NORMAL = os.path.join(MODEL_DIR, "embeddingler_cache.npy")
CACHE_TTA = os.path.join(MODEL_DIR, "embeddingler_tta_cache.npy")

AUG_KATI = {"lidya": 3, "hilal": 3, "sueda": 2, "mina": 2, "esin": 1, "zoktay": 1}
SEED = 42
np.random.seed(SEED)

# v13 esikleri (warm start, baseline kiyaslama icin)
HEURISTIC_THR = {
    "zoktay": 0.65, "hilal": 0.30, "lidya": 0.30,
    "esin": 0.40, "sueda": 0.40, "mina": 0.35,
}
GRID = np.round(np.arange(0.05, 0.96, 0.025), 4)


# ============================================================
def l2_norm(X):
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    return X / (norms + 1e-8)


def emb_augment(emb, n):
    return [emb + np.random.randn(len(emb)) * 0.015 for _ in range(n)]


def cache_yukle(yol):
    cache = np.load(yol, allow_pickle=True).item()
    tum = []
    for kiz in sorted(os.listdir(GIRLS_DIR)):
        kp = os.path.join(GIRLS_DIR, kiz)
        if not os.path.isdir(kp): continue
        for f in sorted(os.listdir(kp)):
            if f.endswith(".wav"):
                tum.append((kiz, os.path.join(kp, f)))
    return cache, tum


def vlog_listesi(tum):
    pat = re.compile(r"^(vlog\d+)_")
    return sorted(
        {pat.match(os.path.basename(y)).group(1) for _, y in tum if pat.match(os.path.basename(y))},
        key=lambda v: int(v[4:]),
    )


def veri_hazirla(tum, cache, egitim_v, test_v, augment=True):
    Xtr, ytr, Xte, yte = [], [], [], []
    for kiz, yol in tum:
        if yol not in cache: continue
        emb = cache[yol]
        ad = os.path.basename(yol)
        if ad.startswith(test_v + "_"):
            Xte.append(emb); yte.append(kiz)
        elif any(ad.startswith(v + "_") for v in egitim_v):
            Xtr.append(emb); ytr.append(kiz)
            if augment:
                for aug in emb_augment(emb, AUG_KATI.get(kiz, 1) - 1):
                    Xtr.append(aug); ytr.append(kiz)
    return np.array(Xtr), np.array(Xte), np.array(ytr), np.array(yte)


def svm_egit(Xtr, ytr_enc):
    model = SVC(kernel="rbf", C=10, gamma="scale", class_weight="balanced",
                probability=True, random_state=SEED)
    model.fit(Xtr, ytr_enc)
    return model


def threshold_pred(probs, le, thr_dict):
    out = []
    for p in probs:
        order = np.argsort(p)[::-1]
        picked = order[0]  # fallback: argmax
        for idx in order:
            if p[idx] >= thr_dict.get(le.classes_[idx], 0.35):
                picked = idx
                break
        out.append(picked)
    return np.array(out)


def macro_f1(y_true, y_pred, k):
    return f1_score(y_true, y_pred, labels=range(k), average="macro", zero_division=0)


def coord_descent_thr(probs, y_true, le, init_thr, n_pass=3):
    """Per-class threshold'lari macro-F1 maksimize edecek sekilde optimize et."""
    thr = dict(init_thr)
    k = len(le.classes_)
    best_global = macro_f1(y_true, threshold_pred(probs, le, thr), k)
    for _ in range(n_pass):
        ilerleme = False
        for cls in le.classes_:
            best_t = thr[cls]
            best_f1 = macro_f1(y_true, threshold_pred(probs, le, thr), k)
            for t in GRID:
                trial = dict(thr); trial[cls] = float(t)
                f1 = macro_f1(y_true, threshold_pred(probs, le, trial), k)
                if f1 > best_f1:
                    best_f1 = f1; best_t = float(t); ilerleme = True
            thr[cls] = best_t
        global_f1 = macro_f1(y_true, threshold_pred(probs, le, thr), k)
        if not ilerleme:
            break
        best_global = global_f1
    return thr, best_global


def inner_oof_probs(tum, cache, egitim_v, le):
    """Training vloglari uzerinde leave-one-vlog-out OOF probability matrisi."""
    oof_X_idx = []  # (kiz, yol) tuples for tracking
    oof_probs = []
    oof_y = []
    for tutulan in egitim_v:
        digerleri = [v for v in egitim_v if v != tutulan]
        Xtr, Xval, ytr, yval = veri_hazirla(tum, cache, digerleri, tutulan, augment=True)
        if len(Xval) == 0: continue
        Xtr = l2_norm(Xtr); Xval = l2_norm(Xval)
        m = svm_egit(Xtr, le.transform(ytr))
        probs = m.predict_proba(Xval)
        oof_probs.append(probs)
        oof_y.append(le.transform(yval))
    if not oof_probs:
        return None, None
    return np.vstack(oof_probs), np.concatenate(oof_y)


def egit_outer(tum, cache, egitim_v, test_v, le, ogrenilen_thr=True):
    Xtr, Xte, ytr, yte = veri_hazirla(tum, cache, egitim_v, test_v, augment=True)
    Xtr = l2_norm(Xtr); Xte = l2_norm(Xte)
    model = svm_egit(Xtr, le.transform(ytr))
    probs = model.predict_proba(Xte)
    yte_enc = le.transform(yte)

    # Argmax (esiksiz)
    y_arg = np.argmax(probs, axis=1)
    acc_arg = accuracy_score(yte_enc, y_arg) * 100

    # Heuristik esik (v13 baseline)
    y_heu = threshold_pred(probs, le, HEURISTIC_THR)
    acc_heu = accuracy_score(yte_enc, y_heu) * 100

    sonuc = {"argmax": acc_arg, "heuristic": acc_heu, "yte": yte_enc, "y_arg": y_arg, "y_heu": y_heu, "probs": probs}

    if ogrenilen_thr:
        # Inner LOO -> OOF probs -> coord descent
        oof_probs, oof_y = inner_oof_probs(tum, cache, egitim_v, le)
        if oof_probs is not None:
            ogr_thr, val_f1 = coord_descent_thr(oof_probs, oof_y, le, HEURISTIC_THR, n_pass=4)
            y_ogr = threshold_pred(probs, le, ogr_thr)
            acc_ogr = accuracy_score(yte_enc, y_ogr) * 100
            sonuc["learned"] = acc_ogr
            sonuc["learned_thr"] = ogr_thr
            sonuc["val_f1"] = val_f1
            sonuc["y_ogr"] = y_ogr

    return sonuc, model


# ============================================================
if __name__ == "__main__":
    cache_tipi = "tta" if "--cache" not in sys.argv else sys.argv[sys.argv.index("--cache") + 1]
    cache_yolu = CACHE_TTA if cache_tipi == "tta" else CACHE_NORMAL
    print("=" * 64)
    print(f"  MANIFEST V14  |  cache={cache_tipi}  |  L2-norm + ogrenilen thr")
    print("=" * 64)

    if not os.path.exists(cache_yolu):
        raise SystemExit(f"Cache yok: {cache_yolu}\nOnce cache_tta_v14.py calistir.")

    t0 = time.time()
    cache, tum = cache_yukle(cache_yolu)
    vloglar = vlog_listesi(tum)
    print(f"[CACHE] {len(cache)} embedding | dosya: {len(tum)} | vlog: {vloglar}")

    le = LabelEncoder()
    le.fit(list(AUG_KATI.keys()))

    sonuclar = []
    for test_v in vloglar:
        egitim_v = [v for v in vloglar if v != test_v]
        print(f"\n[FOLD] test={test_v}  egitim={egitim_v}")
        s, _ = egit_outer(tum, cache, egitim_v, test_v, le, ogrenilen_thr=True)
        sonuclar.append((test_v, s))
        print(f"  Argmax     : %{s['argmax']:.1f}")
        print(f"  Heuristik  : %{s['heuristic']:.1f}  (v13 thr)")
        if "learned" in s:
            print(f"  Ogrenilen  : %{s['learned']:.1f}  (val macro-F1: {s['val_f1']:.3f})")
            print(f"    ogr_thr  : " + ", ".join(f"{k}={v:.2f}" for k, v in s["learned_thr"].items()))

    print("\n" + "=" * 64)
    print("  V14 OZET")
    print("=" * 64)
    print(f"  {'Fold':<10} {'Argmax':>8} {'Heuristik':>10} {'Ogrenilen':>10}")
    arg_list, heu_list, ogr_list = [], [], []
    for test_v, s in sonuclar:
        arg_list.append(s["argmax"])
        heu_list.append(s["heuristic"])
        line = f"  {test_v:<10} {s['argmax']:>7.1f}% {s['heuristic']:>9.1f}%"
        if "learned" in s:
            ogr_list.append(s["learned"])
            line += f" {s['learned']:>9.1f}%"
        print(line)
    print(f"\n  ORTALAMA   {np.mean(arg_list):>7.1f}% {np.mean(heu_list):>9.1f}%", end="")
    if ogr_list:
        print(f" {np.mean(ogr_list):>9.1f}%")
    else:
        print()

    if ogr_list:
        print(f"\n  v14 (ogr) - v14 (heu): {np.mean(ogr_list) - np.mean(heu_list):+.2f}pp")
        print(f"  v14 (heu) - v14 (arg): {np.mean(heu_list) - np.mean(arg_list):+.2f}pp")

    print(f"\n  Toplam sure: {time.time()-t0:.1f}s")
    print("=" * 64)
