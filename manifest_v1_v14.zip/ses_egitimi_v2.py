# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, classification_report
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR VE DÜZENLİ KLASÖR YOLLARI ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")

model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")
if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v2_PRO.pkl")
# Tercümanı (LabelEncoder) da kaydetmeliyiz ki test ederken kim 0 kim 1 bilsin
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani.pkl")

def detayli_ozellik_cikar(dosya_yolu):
    try:
        ses, sr = librosa.load(dosya_yolu, sr=16000, duration=5.0)
        
        mfccs = librosa.feature.mfcc(y=ses, sr=sr, n_mfcc=40)
        mfccs_ortalama = np.mean(mfccs.T, axis=0)
        mfccs_sapma = np.std(mfccs.T, axis=0)
        
        chroma = librosa.feature.chroma_stft(y=ses, sr=sr)
        chroma_ortalama = np.mean(chroma.T, axis=0)
        
        kontrast = librosa.feature.spectral_contrast(y=ses, sr=sr)
        kontrast_ortalama = np.mean(kontrast.T, axis=0)
        
        zcr = librosa.feature.zero_crossing_rate(y=ses)
        zcr_ortalama = np.mean(zcr.T, axis=0)
        
        birlesik_ozellikler = np.hstack([mfccs_ortalama, mfccs_sapma, chroma_ortalama, kontrast_ortalama, zcr_ortalama])
        return birlesik_ozellikler
        
    except Exception as e:
        return None

def pro_modeli_egit():
    print("🎧 Sesler derinlemesine (Deep Listening) analiz ediliyor, bu biraz vakit alabilir...")
    
    X = [] 
    y_text = [] 
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                ozellik = detayli_ozellik_cikar(tam_yol)
                
                if ozellik is not None:
                    X.append(ozellik)
                    y_text.append(kiz_isim)
                    
    X = np.array(X)
    
    # İŞTE ÇÖZÜM: İsimleri sayılara çevir (Örn: esin=0, hilal=1, lidya=2)
    le = LabelEncoder()
    y_numeric = le.fit_transform(y_text)
    
    print(f"\n📊 Toplam {len(X)} dosyanın devasa genetik haritası çıkarıldı!")
    print("🧠 Yapay Sinir Ağı (Neural Network) eğitiliyor...")
    
    X_train, X_test, y_train, y_test = train_test_split(X, y_numeric, test_size=0.2, random_state=42, stratify=y_numeric)
    
    yapay_sinir_agi = make_pipeline(
        StandardScaler(),
        MLPClassifier(hidden_layer_sizes=(256, 128), max_iter=500, alpha=0.01, random_state=42, early_stopping=True)
    )
    
    yapay_sinir_agi.fit(X_train, y_train)
    
    tahminler = yapay_sinir_agi.predict(X_test)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ PROFESYONEL EĞİTİM TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    # Raporu verirken sayıları tekrar kızların isimlerine çevirerek göster
    print(classification_report(y_test, tahminler, target_names=le.classes_))
    
    joblib.dump(yapay_sinir_agi, model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    print(f"💾 Pro Model ve Tercüman şu klasöre kaydedildi: {model_klasoru}")

if __name__ == "__main__":
    pro_modeli_egit()