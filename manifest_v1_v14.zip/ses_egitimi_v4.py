# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, classification_report
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")

if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v4_KONSEY.pkl")
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani.pkl")

def altin_ozellik_cikar(dosya_yolu):
    try:
        ses, sr = librosa.load(dosya_yolu, sr=16000, duration=5.0)
        
        # Sesi baştaki ve sondaki gereksiz sessizliklerden arındır
        ses, _ = librosa.effects.trim(ses, top_db=20)
        
        # Çok kısaysa atla
        if len(ses) < sr * 0.5:
            return None
            
        # 1. MFCC (Sadece ilk 20, en saf insan sesi frekansları)
        mfccs = librosa.feature.mfcc(y=ses, sr=sr, n_mfcc=20)
        
        # 2. Delta (Değişim hızı) ve Delta-Delta (Değişimin ivmesi)
        delta = librosa.feature.delta(mfccs)
        delta2 = librosa.feature.delta(mfccs, order=2)
        
        # Her birinin hem ortalamasını hem de standart sapmasını (dalgalanmasını) al
        # np.hstack ile tek ve çok güçlü bir dizi (vektör) oluştur
        birlesik = np.hstack([
            np.mean(mfccs, axis=1), np.std(mfccs, axis=1),
            np.mean(delta, axis=1), np.std(delta, axis=1),
            np.mean(delta2, axis=1), np.std(delta2, axis=1)
        ])
        
        return birlesik
        
    except Exception as e:
        return None

def konsey_modeli_egit():
    print("🎧 Orijinal sesler temizleniyor ve Altın Özellikler (Delta-Delta) çıkarılıyor...")
    
    X = [] 
    y_text = [] 
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                ozellik = altin_ozellik_cikar(tam_yol)
                
                if ozellik is not None:
                    X.append(ozellik)
                    y_text.append(kiz_isim)
                    
    X = np.array(X)
    le = LabelEncoder()
    y_numeric = le.fit_transform(y_text)
    
    print(f"\n📊 Toplam {len(X)} dosyanın saf gırtlak haritası çıkarıldı.")
    print("🧠 Konsey (Yapay Sinir Ağı + Orman + Regresyon) toplanıyor...")
    
    X_train, X_test, y_train, y_test = train_test_split(X, y_numeric, test_size=0.2, random_state=42, stratify=y_numeric)
    
    # 3 FARKLI UZMAN YAPAY ZEKA
    uzman_1 = MLPClassifier(hidden_layer_sizes=(128, 64), max_iter=500, alpha=0.01, random_state=42)
    uzman_2 = RandomForestClassifier(n_estimators=150, class_weight='balanced', random_state=42)
    uzman_3 = LogisticRegression(max_iter=1000, class_weight='balanced', random_state=42)
    
    # UZMANLARI KONSEYDE (VOTING CLASSIFIER) BİRLEŞTİR
    # soft voting: "Bence %80 Lidya, %20 Esin" gibi olasılıkları toplayıp en mantıklısını seçer
    konsey = make_pipeline(
        StandardScaler(),
        VotingClassifier(estimators=[
            ('SinirAgi', uzman_1),
            ('Orman', uzman_2),
            ('Regresyon', uzman_3)
        ], voting='soft')
    )
    
    konsey.fit(X_train, y_train)
    
    tahminler = konsey.predict(X_test)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ KONSEY EĞİTİMİ TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    print(classification_report(y_test, tahminler, target_names=le.classes_))
    
    joblib.dump(konsey, model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    print(f"💾 Konsey Modeli ve Tercüman kaydedildi: {model_kayit_yolu}")

if __name__ == "__main__":
    konsey_modeli_egit()