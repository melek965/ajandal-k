# -*- coding: utf-8 -*-
import os, warnings, time
import numpy as np
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
from speechbrain.utils.fetching import LocalStrategy

warnings.filterwarnings("ignore")

# ============================================================
#  AYARLAR
# ============================================================
ANA_DIR   = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
GIRLS_DIR = os.path.join(ANA_DIR, "girls")
MODEL_DIR = os.path.join(ANA_DIR, "ses_egitimi", "pkl_modelleri")
EMB_CACHE = os.path.join(MODEL_DIR, "embeddingler_cache.npy")
os.makedirs(MODEL_DIR, exist_ok=True)

AUG_KATI = {'lidya': 3, 'hilal': 3, 'sueda': 2, 'mina': 2, 'esin': 1, 'zoktay': 1}
TUM_VLOGLAR = ["vlog1", "vlog2", "vlog3"]

# Per-class threshold:
# Zoktay yuksek -> "emin degilim" der, az karisitirir
# Hilal/Lidya dusuk -> daha kolay kabul edilir
# Diger: varsayilan 0.35
PER_CLASS_THRESHOLD = {
    'zoktay': 0.65,   # cok agresif tahmin ediyor, dizginle
    'hilal':  0.30,   # az veri, kolaylastir
    'lidya':  0.30,   # az veri, kolaylastir
    'esin':   0.40,
    'sueda':  0.40,
    'mina':   0.35,
}

# ============================================================
#  YARDIMCI
# ============================================================
def emb_augment(emb, n):
    return [emb + np.random.randn(len(emb)) * 0.015 for _ in range(n)]

def cache_yukle():
    cache = np.load(EMB_CACHE, allow_pickle=True).item()
    tum_dosyalar = []
    for kiz in os.listdir(GIRLS_DIR):
        kiz_yolu = os.path.join(GIRLS_DIR, kiz)
        if not os.path.isdir(kiz_yolu): continue
        for f in os.listdir(kiz_yolu):
            if f.endswith(".wav"):
                tum_dosyalar.append((kiz, os.path.join(kiz_yolu, f)))
    print(f"[CACHE] {len(cache)} embedding yuklendi, {len(tum_dosyalar)} dosya.")
    return cache, tum_dosyalar

def veri_hazirla(tum_dosyalar, cache, egitim_vloglari, test_vlogu):
    X_train, y_train = [], []
    X_test,  y_test  = [], []
    for kiz, yol in tum_dosyalar:
        if yol not in cache: continue
        emb = cache[yol]
        dosya = os.path.basename(yol)
        if test_vlogu in dosya:
            X_test.append(emb); y_test.append(kiz)
        elif any(v in dosya for v in egitim_vloglari):
            X_train.append(emb); y_train.append(kiz)
            kat = AUG_KATI.get(kiz, 1)
            for aug in emb_augment(emb, kat - 1):
                X_train.append(aug); y_train.append(kiz)
    return np.array(X_train), np.array(X_test), np.array(y_train), np.array(y_test)

# ============================================================
#  PER-CLASS THRESHOLD TAHMIN
# ============================================================
def threshold_tahmin(ihtimaller, le, threshold_dict):
    """
    Her sinif icin farkli guven esigi uygular.
    En yuksek ihtimalli sinifin esigi gectiyse onu sec,
    gecmediyse ikinci en yuksege bak, o da gectiyse onu sec,
    hicbiri gecmediyse en yuksegi sec (worst-case fallback).
    """
    tahminler = []
    for olasilik in ihtimaller:
        # Sinif indekslerini olasiliga gore sirala (buyukten kucuge)
        siralama = np.argsort(olasilik)[::-1]
        secilen = siralama[0]  # fallback: her zaman en yuksek

        for idx in siralama:
            sinif_adi = le.classes_[idx]
            esik = threshold_dict.get(sinif_adi, 0.35)
            if olasilik[idx] >= esik:
                secilen = idx
                break  # bu sinifi kabul et

        tahminler.append(secilen)
    return np.array(tahminler)

# ============================================================
#  MODEL EGIT + DEGERLENDIR (iki mod: standart vs threshold)
# ============================================================
def egit_ve_karsilastir(X_tr, X_te, y_tr, y_te_str, le, fold_adi, ax_std, ax_thr):
    scaler = StandardScaler()
    X_tr_sc = scaler.fit_transform(X_tr)
    X_te_sc = scaler.transform(X_te)

    model = SVC(kernel='rbf', C=10, gamma='scale',
                class_weight='balanced', probability=True, random_state=42)
    model.fit(X_tr_sc, le.transform(y_tr))

    y_te_enc = le.transform(y_te_str)
    ihtimaller = model.predict_proba(X_te_sc)

    # Standart tahmin (argmax)
    y_std = np.argmax(ihtimaller, axis=1)
    acc_std = accuracy_score(y_te_enc, y_std) * 100

    # Per-class threshold tahmin
    y_thr = threshold_tahmin(ihtimaller, le, PER_CLASS_THRESHOLD)
    acc_thr = accuracy_score(y_te_enc, y_thr) * 100

    print(f"\n  {fold_adi}")
    print(f"  Standart argmax : %{acc_std:.1f}")
    print(f"  Per-class thr   : %{acc_thr:.1f}  ({acc_thr-acc_std:+.1f})")
    print("\n  [Standart]")
    print(classification_report(y_te_enc, y_std, target_names=le.classes_))
    print("  [Per-Class Threshold]")
    print(classification_report(y_te_enc, y_thr, target_names=le.classes_))

    # Confusion matrixler
    for y_pred, ax, baslik, renk in [
        (y_std, ax_std, f'{fold_adi}\nStandart %{acc_std:.1f}', 'Blues'),
        (y_thr, ax_thr, f'{fold_adi}\nThreshold %{acc_thr:.1f}', 'Oranges'),
    ]:
        cm = confusion_matrix(y_te_enc, y_pred, labels=range(len(le.classes_)))
        ConfusionMatrixDisplay(cm, display_labels=le.classes_).plot(ax=ax, cmap=renk, colorbar=False)
        ax.set_title(baslik, fontsize=9)

    return scaler, model, acc_std, acc_thr

# ============================================================
#  ANA AKIS: 3-FOLD + PER-CLASS THRESHOLD KARSILASTIRMASI
# ============================================================
if __name__ == "__main__":
    print("="*55)
    print("  MANIFEST SES TANIMA - V12")
    print("  Per-Class Threshold (Zoktay dizginle)")
    print(f"  Zoktay esik: {PER_CLASS_THRESHOLD['zoktay']}")
    print(f"  Hilal esik : {PER_CLASS_THRESHOLD['hilal']}")
    print(f"  Lidya esik : {PER_CLASS_THRESHOLD['lidya']}")
    print("="*55)
    t0 = time.time()

    cache, tum = cache_yukle()

    le = LabelEncoder()
    le.fit(list(AUG_KATI.keys()))

    # 3 fold x 2 mod = 6 confusion matrix
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))

    std_accs, thr_accs = [], []

    for i, test_vlogu in enumerate(TUM_VLOGLAR):
        egitim = [v for v in TUM_VLOGLAR if v != test_vlogu]
        X_tr, X_te, y_tr, y_te = veri_hazirla(tum, cache, egitim, test_vlogu)

        scaler, model, acc_std, acc_thr = egit_ve_karsilastir(
            X_tr, X_te, y_tr, y_te, le,
            fold_adi=f"Fold {i+1}: test={test_vlogu}",
            ax_std=axes[0][i],
            ax_thr=axes[1][i]
        )
        std_accs.append(acc_std)
        thr_accs.append(acc_thr)

        # En iyi fold'u kaydet
        if test_vlogu == "vlog3":
            joblib.dump((scaler, model, le, PER_CLASS_THRESHOLD),
                        os.path.join(MODEL_DIR, "kizlar_ses_modeli_v12.pkl"))

    plt.suptitle(
        f'V12: Standart vs Per-Class Threshold | '
        f'Std ort: %{np.mean(std_accs):.1f}  Thr ort: %{np.mean(thr_accs):.1f}',
        fontsize=12
    )
    plt.tight_layout()
    yol = os.path.join(MODEL_DIR, "v12_karsilastirma.png")
    plt.savefig(yol, dpi=130); plt.close()

    print("\n" + "="*55)
    print("  V12 FINAL OZET")
    print("="*55)
    for i, (v, s, t) in enumerate(zip(TUM_VLOGLAR, std_accs, thr_accs)):
        print(f"  Fold {i+1} ({v}): Std %{s:.1f}  ->  Threshold %{t:.1f}  ({t-s:+.1f})")
    print(f"\n  Ortalama Standart  : %{np.mean(std_accs):.1f}")
    print(f"  Ortalama Threshold : %{np.mean(thr_accs):.1f}  ({np.mean(thr_accs)-np.mean(std_accs):+.1f})")
    print(f"\n  Gorseller: {yol}")
    print(f"  Toplam sure: {round(time.time()-t0, 1)} sn")
    print("="*55)
