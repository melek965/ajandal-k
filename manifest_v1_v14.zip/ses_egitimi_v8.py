# -*- coding: utf-8 -*-
import os
import torch
import torchaudio
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from speechbrain.inference.classifiers import EncoderClassifier
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")

if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v8_DEEP.pkl")
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani_v8.pkl")

def derin_ogrenme_modeli_egit():
    print("🌍 SpeechBrain ECAPA-TDNN Modeli Yükleniyor... (İlk seferde ~80MB indirebilir)")
    # Dünyanın en iyi Speaker Verification (Ses Doğrulama) modellerinden biri
    ses_dnas_cikarici = EncoderClassifier.from_hparams(source="speechbrain/spkrec-ecapa-voxceleb", savedir="tmpdir")
    
    print("\n🎧 Ses dosyalarının 192 Boyutlu Biyometrik DNA'ları (X-Vectors) çıkarılıyor...")
    print("Bu işlem derin öğrenme kullandığı için biraz sürebilir, arkana yaslan!")
    
    X = []
    y_text = []
    hatali_dosyalar = 0
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                
                try:
                    # Sesi torchaudio ile yükle
                    sinyal, fs = torchaudio.load(tam_yol)
                    
                    # Model 16000 Hz istiyor, eğer farklıysa çevir
                    if fs != 16000:
                        resampler = torchaudio.transforms.Resample(orig_freq=fs, new_freq=16000)
                        sinyal = resampler(sinyal)
                    
                    # Mono sese çevir (eğer stereo ise)
                    if sinyal.shape[0] > 1:
                        sinyal = torch.mean(sinyal, dim=0, keepdim=True)
                        
                    # İŞTE BÜYÜ BURADA: Sesin DNA'sını çıkar (Arka plan gürültüsünü otomatik yok sayar)
                    dna_vektoru = ses_dnas_cikarici.encode_batch(sinyal)
                    
                    # 192 boyutlu DNA'yı düz bir diziye çevir ve listeye ekle
                    dna_dizisi = dna_vektoru.squeeze().numpy()
                    
                    X.append(dna_dizisi)
                    y_text.append(kiz_isim)
                    
                except Exception as e:
                    hatali_dosyalar += 1
                    continue
                    
    X = np.array(X)
    le = LabelEncoder()
    y_numeric = le.fit_transform(y_text)
    
    print(f"\n📊 Toplam {len(X)} dosyanın Biyometrik Ses DNA'sı başarıyla çıkarıldı. ({hatali_dosyalar} dosya atlattı)")
    print("🧠 Logistic Regression (Saf DNA ile) eğitiliyor...")
    
    # Verileri ayır
    X_train, X_test, y_train, y_test = train_test_split(X, y_numeric, test_size=0.2, random_state=42, stratify=y_numeric)
    
    # DNA verisi zaten o kadar kusursuzdur ki, ekstra karmaşık bir algoritmaya gerek kalmaz. 
    # Basit bir Logistic Regresyon bile %80+ başarı gösterir.
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = LogisticRegression(max_iter=1000, class_weight='balanced', random_state=42, C=0.1)
    model.fit(X_train_scaled, y_train)
    
    tahminler = model.predict(X_test_scaled)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ DEEP LEARNING EĞİTİMİ (V8) TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    print(classification_report(y_test, tahminler, target_names=le.classes_))
    
    # Gelecekte tahmin yaparken scaler'a da ihtiyacımız olacak
    joblib.dump((scaler, model), model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    print("💾 V8 Derin Öğrenme Modeli başarıyla kaydedildi.")

if __name__ == "__main__":
    derin_ogrenme_modeli_egit()