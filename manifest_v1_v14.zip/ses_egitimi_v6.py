# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
import warnings
from collections import Counter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")

if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v6_MIKRO.pkl")
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani_v6.pkl")
scaler_kayit_yolu = os.path.join(model_klasoru, "olceklendirici_v6.pkl")

# --- MİKRO DİLİMLEME (1 Saniyelik Parçalar) ---
def mikro_parcalara_ayir(dosya_yolu, parca_suresi=1.0, adim_suresi=0.5):
    try:
        ses, sr = librosa.load(dosya_yolu, sr=16000)
        ses, _ = librosa.effects.trim(ses, top_db=20) # Baştaki/sondaki sessizliği at
        
        parca_ornekleri = int(parca_suresi * sr)
        adim_ornekleri = int(adim_suresi * sr)
        
        ozellikler = []
        
        # Sesi 1 saniyelik dilimler halinde tarayarak ilerle (Sliding Window)
        for baslangic in range(0, len(ses) - parca_ornekleri + 1, adim_ornekleri):
            dilim = ses[baslangic : baslangic + parca_ornekleri]
            
            # Sadece o 1 saniyenin saf frekansını (MFCC) al
            mfccs = librosa.feature.mfcc(y=dilim, sr=sr, n_mfcc=20)
            mfccs_ortalama = np.mean(mfccs.T, axis=0)
            
            # Sesin parlaklığı (Kadın seslerini ayırmada kilit nokta)
            centroid = librosa.feature.spectral_centroid(y=dilim, sr=sr)
            centroid_ortalama = np.mean(centroid.T, axis=0)
            
            birlesik = np.hstack([mfccs_ortalama, centroid_ortalama])
            ozellikler.append(birlesik)
            
        # Eğer dosya 1 saniyeden daha kısaysa, olanı al
        if len(ozellikler) == 0 and len(ses) > sr * 0.2:
            mfccs = librosa.feature.mfcc(y=ses, sr=sr, n_mfcc=20)
            centroid = librosa.feature.spectral_centroid(y=ses, sr=sr)
            birlesik = np.hstack([np.mean(mfccs.T, axis=0), np.mean(centroid.T, axis=0)])
            ozellikler.append(birlesik)
            
        return ozellikler
    except Exception as e:
        return None

def mikro_modeli_egit():
    print("🎧 Dosyalar bulunuyor ve veri sızıntısını önlemek için önce ayrılıyor...")
    dosya_yollari = []
    etiketler = []
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                dosya_yollari.append(os.path.join(kiz_klasoru, ses_dosyasi))
                etiketler.append(kiz_isim)

    # ÖNEMLİ: Parçalamadan ÖNCE Train/Test diye ayırıyoruz ki model ezber (hile) yapmasın!
    X_train_dosyalar, X_test_dosyalar, y_train_etiketler, y_test_etiketler = train_test_split(
        dosya_yollari, etiketler, test_size=0.2, random_state=42, stratify=etiketler
    )

    print("✂️ Eğitim setindeki dosyalar mikro parçalara (1'er saniye) bölünüyor...")
    X_train_mikro = []
    y_train_mikro = []
    
    for yol, etiket in zip(X_train_dosyalar, y_train_etiketler):
        dilimler = mikro_parcalara_ayir(yol)
        if dilimler:
            for dilim in dilimler:
                X_train_mikro.append(dilim)
                y_train_mikro.append(etiket)
                
    X_train_mikro = np.array(X_train_mikro)
    
    le = LabelEncoder()
    y_train_kodlu = le.fit_transform(y_train_mikro)
    
    scaler = StandardScaler()
    X_train_olcekli = scaler.fit_transform(X_train_mikro)

    print(f"\n📈 Eskiden {len(X_train_dosyalar)} verimiz vardı, şimdi {len(X_train_mikro)} adet pürüzsüz mikro sesimiz var!")
    print("🧠 Yapay Sinir Ağı bu saf ses frekanslarını ezberliyor...")

    # Daha derin ve detaycı bir nöral ağ
    model = MLPClassifier(hidden_layer_sizes=(256, 128, 64), max_iter=500, alpha=0.001, random_state=42, early_stopping=True)
    model.fit(X_train_olcekli, y_train_kodlu)

    print("\n🔍 Test Aşaması Başlıyor (Yapay Zeka her dosyayı saniye saniye dinleyip oylama yapıyor)...")
    
    gercek_cevaplar = []
    tahmin_cevaplar = []
    
    for yol, etiket in zip(X_test_dosyalar, y_test_etiketler):
        dilimler = mikro_parcalara_ayir(yol)
        if dilimler:
            dilimler_olcekli = scaler.transform(dilimler)
            
            # Model dosyanın içindeki her 1 saniyeyi tahmin ediyor (Örn: [Lidya, Lidya, Esin, Lidya])
            dilim_tahminleri = model.predict(dilimler_olcekli)
            
            # En çok oyu kim aldıysa, dosyanın sahibi odur!
            en_cok_oy_alan = Counter(dilim_tahminleri).most_common(1)[0][0]
            
            gercek_cevaplar.append(le.transform([etiket])[0])
            tahmin_cevaplar.append(en_cok_oy_alan)
            
    basari = accuracy_score(gercek_cevaplar, tahmin_cevaplar) * 100
    
    print(f"\n✅ MİKRO ANALİZ (V6) EĞİTİMİ TAMAMLANDI! Gerçek Başarı Oranı: %{basari:.2f}")
    print("\n📊 Nihai Oylama Sonucu Sınıflandırma Raporu:")
    print(classification_report(gercek_cevaplar, tahmin_cevaplar, target_names=le.classes_))
    
    joblib.dump(model, model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    joblib.dump(scaler, scaler_kayit_yolu)
    print("💾 V6 Modeli başarıyla kaydedildi.")

if __name__ == "__main__":
    mikro_modeli_egit()