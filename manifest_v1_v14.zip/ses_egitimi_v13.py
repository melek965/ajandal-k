# -*- coding: utf-8 -*-
"""
V13: N-fold cross-vlog (4 vlog ile + auto-discover).

V12'nin core'unu koruyor — SVM RBF + per-class threshold + emb augmentation.
Tek fark: TUM_VLOGLAR'i sabit yazmiyoruz, cache'de hangi `vlogN_` prefix'leri
varsa hepsini fold yapiyoruz. Vlog 4 eklendi -> 4-fold CV. Yeni vlog ekleyince
script tekrar 5-fold yapar.

Linux/Windows portable: yollar __file__ tabanli.
"""
import os, re, time, warnings
import numpy as np
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay

warnings.filterwarnings("ignore")

# ============================================================
#  YOLLAR
# ============================================================
HERE = os.path.dirname(os.path.abspath(__file__))
ANA_DIR = os.path.abspath(os.path.join(HERE, "..", ".."))
GIRLS_DIR = os.path.join(ANA_DIR, "girls")
MODEL_DIR = os.path.join(ANA_DIR, "ses_egitimi", "pkl_modelleri")
EMB_CACHE = os.path.join(MODEL_DIR, "embeddingler_cache.npy")
os.makedirs(MODEL_DIR, exist_ok=True)

# ============================================================
#  AYARLAR
# ============================================================
AUG_KATI = {"lidya": 3, "hilal": 3, "sueda": 2, "mina": 2, "esin": 1, "zoktay": 1}
PER_CLASS_THRESHOLD = {
    "zoktay": 0.65,
    "hilal":  0.30,
    "lidya":  0.30,
    "esin":   0.40,
    "sueda":  0.40,
    "mina":   0.35,
}
SEED = 42
np.random.seed(SEED)


# ============================================================
#  YARDIMCI
# ============================================================
def emb_augment(emb, n):
    return [emb + np.random.randn(len(emb)) * 0.015 for _ in range(n)]


def cache_yukle():
    cache = np.load(EMB_CACHE, allow_pickle=True).item()
    tum = []
    for kiz in sorted(os.listdir(GIRLS_DIR)):
        kp = os.path.join(GIRLS_DIR, kiz)
        if not os.path.isdir(kp): continue
        for f in sorted(os.listdir(kp)):
            if f.endswith(".wav"):
                tum.append((kiz, os.path.join(kp, f)))
    print(f"[CACHE] {len(cache)} embedding yuklendi, {len(tum)} dosya disk uzerinde.")
    return cache, tum


def vlog_listesi(tum_dosyalar):
    """Dosya isimlerinden vlog{N} prefix'lerini tespit eder."""
    pat = re.compile(r"^(vlog\d+)_")
    bulunanlar = set()
    for _, yol in tum_dosyalar:
        m = pat.match(os.path.basename(yol))
        if m:
            bulunanlar.add(m.group(1))
    return sorted(bulunanlar, key=lambda v: int(v[4:]))


def vlog_dagilimi(tum_dosyalar, vloglar):
    print("[DAGILIM] vlog x kiz:")
    print(f"  {'vlog':<7} | " + " | ".join(f"{k:<7}" for k in sorted(AUG_KATI.keys())) + " | TOPLAM")
    for v in vloglar:
        sayim = {k: 0 for k in AUG_KATI.keys()}
        for kiz, yol in tum_dosyalar:
            if os.path.basename(yol).startswith(v + "_"):
                sayim[kiz] += 1
        toplam = sum(sayim.values())
        print(f"  {v:<7} | " + " | ".join(f"{sayim[k]:<7}" for k in sorted(AUG_KATI.keys())) + f" | {toplam}")


def veri_hazirla(tum_dosyalar, cache, egitim_vloglari, test_vlogu):
    X_tr, y_tr, X_te, y_te = [], [], [], []
    for kiz, yol in tum_dosyalar:
        if yol not in cache: continue
        emb = cache[yol]
        ad = os.path.basename(yol)
        if ad.startswith(test_vlogu + "_"):
            X_te.append(emb); y_te.append(kiz)
        elif any(ad.startswith(v + "_") for v in egitim_vloglari):
            X_tr.append(emb); y_tr.append(kiz)
            kat = AUG_KATI.get(kiz, 1)
            for aug in emb_augment(emb, kat - 1):
                X_tr.append(aug); y_tr.append(kiz)
    return np.array(X_tr), np.array(X_te), np.array(y_tr), np.array(y_te)


def threshold_tahmin(ihtimaller, le, threshold_dict):
    tahminler = []
    for olasilik in ihtimaller:
        sira = np.argsort(olasilik)[::-1]
        secilen = sira[0]
        for idx in sira:
            esik = threshold_dict.get(le.classes_[idx], 0.35)
            if olasilik[idx] >= esik:
                secilen = idx
                break
        tahminler.append(secilen)
    return np.array(tahminler)


def egit_ve_test(X_tr, X_te, y_tr, y_te_str, le, ax_std, ax_thr, baslik):
    scaler = StandardScaler()
    X_tr_sc = scaler.fit_transform(X_tr)
    X_te_sc = scaler.transform(X_te)
    model = SVC(kernel="rbf", C=10, gamma="scale", class_weight="balanced",
                probability=True, random_state=SEED)
    model.fit(X_tr_sc, le.transform(y_tr))

    y_te_enc = le.transform(y_te_str)
    ihtimaller = model.predict_proba(X_te_sc)
    y_std = np.argmax(ihtimaller, axis=1)
    y_thr = threshold_tahmin(ihtimaller, le, PER_CLASS_THRESHOLD)
    acc_std = accuracy_score(y_te_enc, y_std) * 100
    acc_thr = accuracy_score(y_te_enc, y_thr) * 100

    print(f"\n  {baslik}")
    print(f"  Standart : %{acc_std:.1f}  |  Threshold : %{acc_thr:.1f}  ({acc_thr-acc_std:+.1f})")
    print(classification_report(y_te_enc, y_thr, target_names=le.classes_, zero_division=0))

    cm_std = confusion_matrix(y_te_enc, y_std, labels=range(len(le.classes_)))
    cm_thr = confusion_matrix(y_te_enc, y_thr, labels=range(len(le.classes_)))
    ConfusionMatrixDisplay(cm_std, display_labels=le.classes_).plot(ax=ax_std, cmap="Blues", colorbar=False)
    ConfusionMatrixDisplay(cm_thr, display_labels=le.classes_).plot(ax=ax_thr, cmap="Oranges", colorbar=False)
    ax_std.set_title(f"{baslik}\nStd %{acc_std:.1f}", fontsize=9)
    ax_thr.set_title(f"{baslik}\nThr %{acc_thr:.1f}", fontsize=9)
    return scaler, model, acc_std, acc_thr


# ============================================================
#  ANA AKIS
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  MANIFEST SES TANIMA - V13 (N-fold cross-vlog)")
    print("=" * 60)
    t0 = time.time()

    if not os.path.exists(EMB_CACHE):
        raise SystemExit(f"Cache yok: {EMB_CACHE}")

    cache, tum = cache_yukle()
    vloglar = vlog_listesi(tum)
    print(f"[INFO] Tespit edilen vloglar: {vloglar}  ({len(vloglar)}-fold)")
    vlog_dagilimi(tum, vloglar)

    le = LabelEncoder()
    le.fit(list(AUG_KATI.keys()))

    n = len(vloglar)
    fig, axes = plt.subplots(2, n, figsize=(5 * n, 10))
    if n == 1:
        axes = axes.reshape(2, 1)

    std_accs, thr_accs = [], []
    en_iyi_thr = -1
    en_iyi_paket = None

    for i, test_v in enumerate(vloglar):
        egitim = [v for v in vloglar if v != test_v]
        X_tr, X_te, y_tr, y_te = veri_hazirla(tum, cache, egitim, test_v)
        if len(X_te) == 0:
            print(f"  Fold {i+1} ({test_v}): test bos, atlandi")
            continue
        baslik = f"Fold {i+1}: test={test_v} (n={len(X_te)})"
        scaler, model, acc_std, acc_thr = egit_ve_test(
            X_tr, X_te, y_tr, y_te, le, axes[0][i], axes[1][i], baslik
        )
        std_accs.append(acc_std)
        thr_accs.append(acc_thr)
        if acc_thr > en_iyi_thr:
            en_iyi_thr = acc_thr
            en_iyi_paket = (scaler, model, le, PER_CLASS_THRESHOLD, test_v, acc_thr)

    plt.suptitle(
        f"V13: {n}-Fold Cross-Vlog | Std ort %{np.mean(std_accs):.1f}  Thr ort %{np.mean(thr_accs):.1f}",
        fontsize=12,
    )
    plt.tight_layout()
    yol = os.path.join(MODEL_DIR, f"v13_{n}fold_karsilastirma.png")
    plt.savefig(yol, dpi=130)
    plt.close()

    if en_iyi_paket:
        joblib.dump(en_iyi_paket[:4], os.path.join(MODEL_DIR, "kizlar_ses_modeli_v13.pkl"))

    print("\n" + "=" * 60)
    print("  V13 OZET")
    print("=" * 60)
    for v, s, t in zip(vloglar, std_accs, thr_accs):
        print(f"  Fold {v}: Std %{s:.1f}  ->  Threshold %{t:.1f}  ({t-s:+.1f})")
    print(f"\n  Ortalama Standart  : %{np.mean(std_accs):.1f}  (+/- %{np.std(std_accs):.1f})")
    print(f"  Ortalama Threshold : %{np.mean(thr_accs):.1f}  (+/- %{np.std(thr_accs):.1f})")
    if en_iyi_paket:
        print(f"  En iyi fold        : test={en_iyi_paket[4]} %{en_iyi_paket[5]:.1f}")
    print(f"\n  Gorsel: {yol}")
    print(f"  Toplam sure: {time.time()-t0:.1f} sn")
    print("=" * 60)
