# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, classification_report
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")
if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v3_ULTIMATE.pkl")
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani.pkl")

def detayli_ozellik_cikar(dosya_yolu):
    try:
        ses, sr = librosa.load(dosya_yolu, sr=16000, duration=5.0)
        
        # 1. MFCC ve MFCC Delta (Sesin hızı ve ivmesi - Konuşma tarzını ele verir)
        mfccs = librosa.feature.mfcc(y=ses, sr=sr, n_mfcc=40)
        mfcc_delta = librosa.feature.delta(mfccs) # YENİ SİLAH!
        
        mfccs_ortalama = np.mean(mfccs.T, axis=0)
        mfccs_sapma = np.std(mfccs.T, axis=0)
        delta_ortalama = np.mean(mfcc_delta.T, axis=0)
        
        # 2. Chroma ve Diğerleri
        chroma = librosa.feature.chroma_stft(y=ses, sr=sr)
        chroma_ortalama = np.mean(chroma.T, axis=0)
        
        kontrast = librosa.feature.spectral_contrast(y=ses, sr=sr)
        kontrast_ortalama = np.mean(kontrast.T, axis=0)
        
        zcr = librosa.feature.zero_crossing_rate(y=ses)
        zcr_ortalama = np.mean(zcr.T, axis=0)
        
        # Bütün bu özellikleri devasa bir vektörde birleştir (Artık elimizde çok daha fazla detay var)
        birlesik = np.hstack([mfccs_ortalama, mfccs_sapma, delta_ortalama, chroma_ortalama, kontrast_ortalama, zcr_ortalama])
        return birlesik
        
    except Exception as e:
        return None

def ultimate_modeli_egit():
    print("🎧 Ses dinamikleri (Deltalar) hesaplanıyor, pür dikkat dinleniyor...")
    
    X = [] 
    y_text = [] 
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                ozellik = detayli_ozellik_cikar(tam_yol)
                
                if ozellik is not None:
                    X.append(ozellik)
                    y_text.append(kiz_isim)
                    
    X = np.array(X)
    
    le = LabelEncoder()
    y_numeric = le.fit_transform(y_text)
    
    print(f"\n📊 Toplam {len(X)} dosya çıkarıldı.")
    print("🧠 Support Vector Machine (SVM) eğitiliyor...")
    
    X_train, X_test, y_train, y_test = train_test_split(X, y_numeric, test_size=0.2, random_state=42, stratify=y_numeric)
    
    # İŞTE ULTIMATE SİLAH: SVC (Support Vector Classifier) ve class_weight='balanced'
    # Bu ayar sayesinde Lidya gibi az verisi olan kızlara haksızlık yapılmayacak!
    yapay_zeka = make_pipeline(
        StandardScaler(),
        SVC(kernel='rbf', C=10, gamma='scale', class_weight='balanced', random_state=42)
    )
    
    yapay_zeka.fit(X_train, y_train)
    
    tahminler = yapay_zeka.predict(X_test)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ ULTIMATE EĞİTİM TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    print(classification_report(y_test, tahminler, target_names=le.classes_))
    
    joblib.dump(yapay_zeka, model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    print(f"💾 Ultimate Model kaydedildi: {model_klasoru}")

if __name__ == "__main__":
    ultimate_modeli_egit()