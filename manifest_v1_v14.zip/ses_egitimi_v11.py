# -*- coding: utf-8 -*-
import os, warnings, time
import numpy as np
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
from speechbrain.inference.classifiers import EncoderClassifier
from speechbrain.utils.fetching import LocalStrategy

warnings.filterwarnings("ignore")

# ============================================================
#  AYARLAR
# ============================================================
ANA_DIR   = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
GIRLS_DIR = os.path.join(ANA_DIR, "girls")
MODEL_DIR = os.path.join(ANA_DIR, "ses_egitimi", "pkl_modelleri")
EMB_CACHE = os.path.join(MODEL_DIR, "embeddingler_cache.npy")
os.makedirs(MODEL_DIR, exist_ok=True)

AUG_KATI = {'lidya': 3, 'hilal': 3, 'sueda': 2, 'mina': 2, 'esin': 1, 'zoktay': 1}
GUVEN_ESIGI = 0.50
TUM_VLOGLAR = ["vlog1", "vlog2", "vlog3"]

# ============================================================
#  YARDIMCI
# ============================================================
def emb_augment(emb, n):
    return [emb + np.random.randn(len(emb)) * 0.015 for _ in range(n)]

def cache_yukle():
    print("[CACHE] Embedding cache yukleniyor...")
    cache = np.load(EMB_CACHE, allow_pickle=True).item()
    print(f"  {len(cache)} embedding hazir.")

    tum_dosyalar = []
    for kiz in os.listdir(GIRLS_DIR):
        kiz_yolu = os.path.join(GIRLS_DIR, kiz)
        if not os.path.isdir(kiz_yolu): continue
        for f in os.listdir(kiz_yolu):
            if f.endswith(".wav"):
                tum_dosyalar.append((kiz, os.path.join(kiz_yolu, f)))
    return cache, tum_dosyalar

def veri_hazirla(tum_dosyalar, cache, egitim_vloglari, test_vlogu):
    X_train, y_train = [], []
    X_test,  y_test  = [], []

    for kiz, yol in tum_dosyalar:
        if yol not in cache: continue
        emb = cache[yol]
        dosya = os.path.basename(yol)

        if test_vlogu in dosya:
            X_test.append(emb)
            y_test.append(kiz)
        elif any(v in dosya for v in egitim_vloglari):
            X_train.append(emb)
            y_train.append(kiz)
            kat = AUG_KATI.get(kiz, 1)
            if kat > 1:
                for aug in emb_augment(emb, kat - 1):
                    X_train.append(aug)
                    y_train.append(kiz)

    return (np.array(X_train), np.array(X_test),
            np.array(y_train), np.array(y_test))

def svm_egit_ve_test(X_tr, X_te, y_tr, y_te_str, le):
    scaler = StandardScaler()
    X_tr_sc = scaler.fit_transform(X_tr)
    X_te_sc = scaler.transform(X_te)

    model = SVC(kernel='rbf', C=10, gamma='scale',
                class_weight='balanced', probability=True, random_state=42)
    model.fit(X_tr_sc, le.transform(y_tr))

    y_te_enc = le.transform(y_te_str)
    ihtimaller = model.predict_proba(X_te_sc)
    y_pred = np.argmax(ihtimaller, axis=1)

    acc = accuracy_score(y_te_enc, y_pred) * 100
    return scaler, model, acc, y_te_enc, y_pred, ihtimaller

# ============================================================
#  BOLUM A: SVM TEK BASINA (vlog3 holdout)
# ============================================================
def bolum_a_svm_holdout(tum_dosyalar, cache):
    print("\n" + "="*55)
    print("  BOLUM A: SVM Tek Basina (vlog3 holdout)")
    print("="*55)

    le = LabelEncoder()
    le.fit(list(AUG_KATI.keys()))

    egitim = [v for v in TUM_VLOGLAR if v != "vlog3"]
    X_tr, X_te, y_tr, y_te = veri_hazirla(tum_dosyalar, cache, egitim, "vlog3")

    print(f"  Egitim: {egitim}  |  Test: vlog3")
    from collections import Counter
    for kiz, adet in sorted(Counter(y_tr.tolist()).items()):
        print(f"    {kiz:<10}: {adet}")

    scaler, model, acc, y_te_enc, y_pred, _ = svm_egit_ve_test(X_tr, X_te, y_tr, y_te, le)

    print(f"\n  Accuracy (esiksiz): %{acc:.1f}")
    print(f"  V10 ile karsilastirma: %82.5 -> %{acc:.1f}")
    print(classification_report(y_te_enc, y_pred, target_names=le.classes_))

    # Confusion matrix
    cm = confusion_matrix(y_te_enc, y_pred, labels=range(len(le.classes_)))
    fig, ax = plt.subplots(figsize=(8, 6))
    ConfusionMatrixDisplay(cm, display_labels=le.classes_).plot(ax=ax, cmap='Greens', colorbar=False)
    ax.set_title(f'V11-A: SVM | vlog3 holdout | Acc: %{acc:.1f}')
    plt.tight_layout()
    yol = os.path.join(MODEL_DIR, "v11a_confusion_matrix.png")
    plt.savefig(yol, dpi=150); plt.close()
    print(f"  Confusion matrix: {yol}")

    return scaler, model, le, acc

# ============================================================
#  BOLUM B: 3-FOLD CROSS-VLOG
# ============================================================
def bolum_b_cross_vlog(tum_dosyalar, cache):
    print("\n" + "="*55)
    print("  BOLUM B: 3-Fold Cross-Vlog Rotasyonu")
    print("="*55)

    le = LabelEncoder()
    le.fit(list(AUG_KATI.keys()))

    fold_sonuclari = []

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    for i, test_vlogu in enumerate(TUM_VLOGLAR):
        egitim_vloglari = [v for v in TUM_VLOGLAR if v != test_vlogu]
        X_tr, X_te, y_tr, y_te = veri_hazirla(tum_dosyalar, cache, egitim_vloglari, test_vlogu)

        if len(X_te) == 0:
            print(f"  Fold {i+1} ({test_vlogu}): Test verisi yok, atlaniyor.")
            continue

        _, _, acc, y_te_enc, y_pred, _ = svm_egit_ve_test(X_tr, X_te, y_tr, y_te, le)
        fold_sonuclari.append(acc)

        print(f"\n  Fold {i+1}: Egitim={egitim_vloglari}  Test={test_vlogu}")
        print(f"  Accuracy: %{acc:.1f}")
        print(classification_report(y_te_enc, y_pred, target_names=le.classes_))

        cm = confusion_matrix(y_te_enc, y_pred, labels=range(len(le.classes_)))
        ConfusionMatrixDisplay(cm, display_labels=le.classes_).plot(
            ax=axes[i], cmap='Oranges', colorbar=False)
        axes[i].set_title(f'Fold {i+1}: test={test_vlogu}\nAcc: %{acc:.1f}')

    ort_acc = np.mean(fold_sonuclari)
    std_acc = np.std(fold_sonuclari)

    print("\n" + "="*55)
    print("  3-FOLD OZET")
    print("="*55)
    for i, (v, a) in enumerate(zip(TUM_VLOGLAR, fold_sonuclari)):
        print(f"  Fold {i+1} ({v} test): %{a:.1f}")
    print(f"  Ortalama Accuracy: %{ort_acc:.1f} (+/- %{std_acc:.1f})")
    print("="*55)

    plt.suptitle(f'V11-B: 3-Fold Cross-Vlog | Ort: %{ort_acc:.1f} ± %{std_acc:.1f}', fontsize=13)
    plt.tight_layout()
    yol = os.path.join(MODEL_DIR, "v11b_crossvlog_confusion.png")
    plt.savefig(yol, dpi=150); plt.close()
    print(f"  Tum foldlar confusion matrix: {yol}")

    return ort_acc, std_acc, fold_sonuclari

# ============================================================
#  ANA AKIS
# ============================================================
if __name__ == "__main__":
    print("="*55)
    print("  MANIFEST SES TANIMA - V11")
    print("  BOLUM A: SVM tek basina (GBM cikarildi)")
    print("  BOLUM B: 3-Fold Cross-Vlog rotasyonu")
    print("="*55)
    t0 = time.time()

    # Cache zaten hazir, SpeechBrain'e gerek yok
    if not os.path.exists(EMB_CACHE):
        print("Cache bulunamadi! Once v9 veya v10 calistir.")
        import sys; sys.exit(1)

    cache, tum = cache_yukle()

    # BOLUM A
    scaler_a, model_a, le_a, acc_a = bolum_a_svm_holdout(tum, cache)
    joblib.dump((scaler_a, model_a), os.path.join(MODEL_DIR, "kizlar_ses_modeli_v11.pkl"))
    joblib.dump(le_a, os.path.join(MODEL_DIR, "isim_tercumani_v11.pkl"))

    # BOLUM B
    ort_acc, std_acc, foldlar = bolum_b_cross_vlog(tum, cache)

    print("\n" + "="*55)
    print("  FINAL OZET")
    print("="*55)
    print(f"  V9  (LR,  vlog3 holdout): %78.5")
    print(f"  V10 (Ensemble, vlog3)   : %82.5")
    print(f"  V11A (SVM, vlog3)       : %{acc_a:.1f}")
    print(f"  V11B (SVM, 3-fold ort)  : %{ort_acc:.1f} +/- %{std_acc:.1f}")
    print("="*55)
    print(f"\n  Toplam sure: {round(time.time()-t0, 1)} sn")
