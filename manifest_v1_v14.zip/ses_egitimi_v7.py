# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")

if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v7_BOOSTING.pkl")
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani_v7.pkl")

def gürbüz_ozellik_cikar(dosya_yolu):
    try:
        ses, sr = librosa.load(dosya_yolu, sr=16000)
        
        # 1. ENERJİ FİLTRESİ: Sadece yüksek sesle konuşulan kısımları al (Gürültüyü engeller)
        rms = librosa.feature.rms(y=ses)[0]
        # Enerjisi, ortalama enerjinin %50'sinden yüksek olan "güçlü" anları seç
        saf_ses_indeksleri = np.where(rms > (np.mean(rms) * 0.5))[0]
        
        # Eğer elde hiç ses kalmadıysa veya dosya çok kısaysa atla
        if len(saf_ses_indeksleri) < 5:
            return None
            
        # Sadece saf sesin olduğu anları alıp yeni bir ses dalgası oluştur
        cerceve_boyutu = 512 # librosa'nın varsayılanı
        temiz_ses = np.concatenate([ses[i * cerceve_boyutu : (i + 1) * cerceve_boyutu] for i in saf_ses_indeksleri])
        
        if len(temiz_ses) < sr * 0.5:
            return None # Yarım saniyeden kısa temiz ses varsa çöpe at
            
        # 2. ÖZELLİK ÇIKARIMI (En kritik frekanslar)
        mfcc = librosa.feature.mfcc(y=temiz_ses, sr=sr, n_mfcc=13) # 40 değil 13! Sadece saf insan gırtlağı.
        delta = librosa.feature.delta(mfcc)
        delta2 = librosa.feature.delta(mfcc, order=2)
        
        centroid = librosa.feature.spectral_centroid(y=temiz_ses, sr=sr)
        bandwidth = librosa.feature.spectral_bandwidth(y=temiz_ses, sr=sr)
        
        # Sadece ortalamaları ve dalgalanmaları (std) birleştir
        birlesik = np.hstack([
            np.mean(mfcc, axis=1), np.std(mfcc, axis=1),
            np.mean(delta, axis=1), np.std(delta, axis=1),
            np.mean(delta2, axis=1), np.std(delta2, axis=1),
            np.mean(centroid), np.std(centroid),
            np.mean(bandwidth), np.std(bandwidth)
        ])
        
        return birlesik
        
    except Exception as e:
        return None

def boosting_modeli_egit():
    print("🎧 Güçlü Enerji Filtresi uygulanıyor... (Fısıltılar ve arkadaki uğultular siliniyor)")
    
    X = []
    y_text = []
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                ozellik = gürbüz_ozellik_cikar(tam_yol)
                
                if ozellik is not None:
                    X.append(ozellik)
                    y_text.append(kiz_isim)
                    
    X = np.array(X)
    le = LabelEncoder()
    y_numeric = le.fit_transform(y_text)
    
    print(f"\n📊 Toplam {len(X)} adet PÜRÜZSÜZ dosya kaldı (Gürültülüler acımasızca elendi).")
    print("🧠 LightGBM (HistGradientBoosting) Şampiyon Algoritması eğitiliyor...")
    
    X_train, X_test, y_train, y_test = train_test_split(X, y_numeric, test_size=0.2, random_state=42, stratify=y_numeric)
    
    # HistGradientBoosting: Ölçeklendirmeye (StandardScaler) ihtiyaç duymaz! Gürültülü verilere karşı inanılmaz dirençlidir.
    # Sueda'ya veya Mina'ya haksızlık yapmasın diye class_weight ayarını dengeli veriyoruz (sample_weight ile)
    
    # Sınıf ağırlıklarını manuel hesaplayalım (HistGradientBoosting'de class_weight parametresi doğrudan yoktur)
    sinif_agirliklari = {}
    for sinif in np.unique(y_train):
        sinif_agirliklari[sinif] = len(y_train) / (len(np.unique(y_train)) * np.sum(y_train == sinif))
        
    ornek_agirliklari = np.array([sinif_agirliklari[sinif] for sinif in y_train])
    
    model = HistGradientBoostingClassifier(
        max_iter=500, 
        learning_rate=0.05, 
        max_depth=15, 
        min_samples_leaf=10, 
        random_state=42,
        early_stopping=True
    )
    
    # Modeli özel ağırlıklarla eğit
    model.fit(X_train, y_train, sample_weight=ornek_agirliklari)
    
    tahminler = model.predict(X_test)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ BOOSTING EĞİTİMİ (V7) TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    print(classification_report(y_test, tahminler, target_names=le.classes_))
    
    joblib.dump(model, model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    print("💾 V7 Boosting Modeli başarıyla kaydedildi.")

if __name__ == "__main__":
    boosting_modeli_egit()