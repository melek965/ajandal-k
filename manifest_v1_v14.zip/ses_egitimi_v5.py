# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

warnings.filterwarnings("ignore")

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_klasoru = os.path.join(ana_dizin, "ses_egitimi", "pkl_modelleri")

if not os.path.exists(model_klasoru):
    os.makedirs(model_klasoru)

model_kayit_yolu = os.path.join(model_klasoru, "kizlar_ses_modeli_v5_XRAY.pkl")
encoder_kayit_yolu = os.path.join(model_klasoru, "isim_tercumani.pkl")

def xray_ozellik_cikar(dosya_yolu):
    try:
        ses, sr = librosa.load(dosya_yolu, sr=16000, duration=5.0)
        ses, _ = librosa.effects.trim(ses, top_db=20)
        
        if len(ses) < sr * 0.5:
            return None
            
        # 1. Saf Ses Frekansları (İlk 20 MFCC)
        mfccs = librosa.feature.mfcc(y=ses, sr=sr, n_mfcc=20)
        
        # 2. Sesin Parlaklığı ve Tizliği (Kızların sesini en çok ayıran özellik)
        centroid = librosa.feature.spectral_centroid(y=ses, sr=sr)
        rolloff = librosa.feature.spectral_rolloff(y=ses, sr=sr)
        
        # İŞTE RÖNTGEN BURADA: Sadece ortalama değil, 5 farklı istatistik!
        # Böylece arkada müzik olsa bile, "Maksimum" veya "Medyan" değerler asıl sesi yakalar.
        birlesik = np.hstack([
            np.mean(mfccs, axis=1), 
            np.std(mfccs, axis=1),
            np.max(mfccs, axis=1), 
            np.min(mfccs, axis=1),
            np.median(mfccs, axis=1),
            
            # Parlaklık (Centroid) istatistikleri
            np.mean(centroid, axis=1), np.std(centroid, axis=1),
            
            # Derinlik (Rolloff) istatistikleri
            np.mean(rolloff, axis=1), np.std(rolloff, axis=1)
        ])
        
        return birlesik
        
    except Exception as e:
        return None

def xray_modeli_egit():
    print("🎧 Seslerin Röntgeni (Min, Max, Medyan, Parlaklık) çekiliyor...")
    
    X = [] 
    y_text = [] 
    
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                ozellik = xray_ozellik_cikar(tam_yol)
                
                if ozellik is not None:
                    X.append(ozellik)
                    y_text.append(kiz_isim)
                    
    X = np.array(X)
    le = LabelEncoder()
    y_numeric = le.fit_transform(y_text)
    
    print(f"\n📊 Toplam {len(X)} dosyanın detaylı röntgeni çekildi.")
    print("🧠 Extra Trees (Aşırı Rastgele Ağaçlar) Yapay Zekası eğitiliyor...")
    
    X_train, X_test, y_train, y_test = train_test_split(X, y_numeric, test_size=0.2, random_state=42, stratify=y_numeric)
    
    # ExtraTrees: Gürültülü ve karmaşık Youtube seslerinde karar ağaçlarından çok daha iyi performans verir.
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = ExtraTreesClassifier(n_estimators=300, class_weight='balanced', max_depth=20, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    tahminler = model.predict(X_test_scaled)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ X-RAY EĞİTİMİ TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    print(classification_report(y_test, tahminler, target_names=le.classes_))
    
    # Pipeline olarak kaydet ki test ederken direkt kullanılabilsin
    joblib.dump((scaler, model), model_kayit_yolu)
    joblib.dump(le, encoder_kayit_yolu)
    print(f"💾 X-Ray Modeli ve Tercüman kaydedildi: {model_klasoru}")

if __name__ == "__main__":
    xray_modeli_egit()