# -*- coding: utf-8 -*-
import os
import librosa
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

# --- AYARLAR ---
ana_dizin = r"D:\alpereinstein\part of my life\university\lectures\department\26'\spring\ai_projects\manifest\manifest_ses"
veri_klasoru = os.path.join(ana_dizin, "girls")
model_kayit_yolu = os.path.join(ana_dizin, "kizlar_ses_modeli.pkl")

# Özellik (MFCC) çıkarma fonksiyonu
def ozellik_cikar(dosya_yolu):
    try:
        # Sesi yükle (librosa kullanıyoruz çünkü frekans analizinde en iyisidir)
        ses, sr = librosa.load(dosya_yolu, sr=16000, duration=3.0) # Her sesin ilk 3 saniyesini al
        
        # MFCC (Mel-frequency cepstral coefficients) hesapla - Sesin "parmak izi"
        mfccs = librosa.feature.mfcc(y=ses, sr=sr, n_mfcc=40)
        
        # Zaman ekseni boyunca ortalamasını alıp tek boyutlu bir diziye (vektöre) çevir
        mfccs_ortalama = np.mean(mfccs.T, axis=0)
        return mfccs_ortalama
    except Exception as e:
        print(f"Hata ({dosya_yolu}): {e}")
        return None

def modeli_egit():
    print("🎧 'girls' klasöründeki seslerin frekans (MFCC) parmak izleri çıkarılıyor...")
    
    X = [] # Ses özellikleri (Parmak izleri)
    y = [] # İsim etiketleri (Zoktay, Lidya vs.)
    
    # Klasördeki her kızı ve seslerini gez
    for kiz_isim in os.listdir(veri_klasoru):
        kiz_klasoru = os.path.join(veri_klasoru, kiz_isim)
        if not os.path.isdir(kiz_klasoru): continue
        
        for ses_dosyasi in os.listdir(kiz_klasoru):
            if ses_dosyasi.endswith(".wav"):
                tam_yol = os.path.join(kiz_klasoru, ses_dosyasi)
                ozellik = ozellik_cikar(tam_yol)
                
                if ozellik is not None:
                    X.append(ozellik)
                    y.append(kiz_isim)
                    
    X = np.array(X)
    y = np.array(y)
    
    print(f"\n📊 Toplam {len(X)} ses dosyası başarıyla işlendi!")
    print("🧠 Yapay Zeka (Random Forest) eğitimi başlıyor...")
    
    # Veriyi Eğitim (%80) ve Test (%20) olarak ikiye böl
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 1 Dakikada eğitilen o meşhur model :)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Modeli test et ve başarı oranını ölç
    tahminler = model.predict(X_test)
    basari = accuracy_score(y_test, tahminler) * 100
    
    print(f"\n✅ EĞİTİM TAMAMLANDI! Model Başarı Oranı: %{basari:.2f}")
    print("\n🔍 Detaylı Sınıflandırma Raporu:")
    print(classification_report(y_test, tahminler))
    
    # Eğitilen modeli daha sonra kullanmak üzere kaydet
    joblib.dump(model, model_kayit_yolu)
    print(f"💾 Model şuraya kaydedildi: {model_kayit_yolu}")

if __name__ == "__main__":
    modeli_egit()