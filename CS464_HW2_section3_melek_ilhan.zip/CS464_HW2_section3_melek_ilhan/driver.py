"""
Entry point that runs both Question 1 (PCA) and Question 2 (Logistic Regression).

"""

import sys
import os

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    ffhq_path = sys.argv[1]
    gene_path = sys.argv[2]
    output_dir = os.path.join(os.path.dirname(__file__), 'outputs')
    os.makedirs(output_dir, exist_ok=True)

    # ── Question 1: PCA ──────────────────────────────────────────────────────
    print("=" * 60)
    print("  QUESTION 1: PCA Analysis")
    print("=" * 60)
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'q1_pca'))
    import pca as pca_module
    pca_module.main(ffhq_path, output_dir=output_dir)

    # ── Question 2: Logistic Regression ─────────────────────────────────────
    print("\n" + "=" * 60)
    print("  QUESTION 2: Logistic Regression")
    print("=" * 60)
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'q2_logistic'))
    import logistic as lr_module
    lr_module.main(gene_path, output_dir=output_dir)

    print("\n" + "=" * 60)
    print(f"  All outputs written to: {output_dir}")
    print("=" * 60)


if __name__ == '__main__':
    main()
