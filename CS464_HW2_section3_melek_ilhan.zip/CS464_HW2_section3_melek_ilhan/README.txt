CS464 HW2 - README
==================

REQUIREMENTS
------------
Python >= 3.8
numpy
Pillow
matplotlib
kagglehub 

Install dependencies:
    pip install numpy Pillow matplotlib kagglehub


DATASET SETUP
-------------
Question 1 - FFHQ Face Images:
    Download from Kaggle using kagglehub:

        import kagglehub
        path = kagglehub.dataset_download("denislukovnikov/ffhq256-images-only")
        # Images are inside: <path>/ffhq256/

    Or download manually and extract so images sit inside a folder called ffhq256/.

Question 2 - Gene Expression Data:
    Download from the Google Drive link provided in the assignment:
        https://drive.google.com/drive/folders/1oENGIeSRTmu-4703bgkls3PEO4ErUgyV

    The folder should contain two files:
        data.csv    - 801 rows x 301 columns (sample_id + 300 gene features)
        labels.csv  - 801 rows x 2 columns  (sample_id + Class label)


HOW TO RUN
----------
Run everything at once:
    python driver.py <path_to_ffhq256_folder> <path_to_gene_data_folder>

    Example:
        python driver.py /home/user/data/ffhq256 /home/user/data/gene_data

Run only Question 1 (PCA):
    cd q1_pca
    python pca.py <path_to_ffhq256_folder>

Run only Question 2 (Logistic Regression):
    cd q2_logistic
    python logistic.py <path_to_gene_data_folder>


OUTPUT FILES
------------
All figures are saved to the outputs/ directory.

    q1_1_pve.png              Bar chart of PVE for first 10 PCs per channel
    q1_2_eigenvectors.png     First 10 principal components as RGB images
    q1_3_reconstruction.png   Image reconstruction for k in {1,50,250,500,1000,4096}
    q1_4_noisy.png            Original vs noisy image (sigma=25)
    q1_4_denoised.png         Denoised images for k in {10,50,100,250,500}
    q1_4_mse.png              MSE vs k per colour channel
    q2_1_loss.png             Training loss curve - Standard BGD
    q2_2_loss_weighted.png    Training loss curve - Weighted BGD
    q2_3_pr_curves.png        Precision-Recall curves for both models


