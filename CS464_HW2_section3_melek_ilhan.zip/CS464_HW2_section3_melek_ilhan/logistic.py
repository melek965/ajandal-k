"""
CS464 HW2 - Question 2: Binary Logistic Regression on Gene Expression Data
"""

import numpy as np
import matplotlib.pyplot as plt
import os
import sys
import csv


# Data Loading 

def load_data(data_dir):
    """Load features and labels from the gene expression dataset."""
    # Expected files: data.csv (or similar) containing features + label
    # The dataset from Google Drive has 'data.csv' and 'labels.csv'   

    data_file   = os.path.join(data_dir, 'data.csv')
    labels_file = os.path.join(data_dir, 'labels.csv')

    # Load features
    with open(data_file, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)
        rows   = [list(map(float, row[1:])) for row in reader]  
    X = np.array(rows, dtype=np.float32)

    # Load labels – "COAD" → 1, everything else → 0
    with open(labels_file, 'r') as f:
        reader = csv.reader(f)
        next(reader)                                              
        y = np.array([1 if row[1].strip() == 'COAD' else 0
                      for row in reader], dtype=np.float32)

    print(f"Data shape : {X.shape}")
    print(f"Label dist : {np.bincount(y.astype(int))}")
    return X, y


# Pre-processing 

def minmax_normalize(X_train, X_test):
    """Min-max normalisation fitted on training set only."""
    X_min = X_train.min(axis=0)
    X_max = X_train.max(axis=0)
    denom = X_max - X_min
    denom[denom == 0] = 1         
    X_train_n = (X_train - X_min) / denom
    X_test_n  = (X_test  - X_min) / denom
    return X_train_n, X_test_n


def train_test_split(X, y, test_frac=0.30, seed=42):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(y))
    n_test  = int(len(y) * test_frac)
    test_idx  = idx[:n_test]
    train_idx = idx[n_test:]
    return X[train_idx], X[test_idx], y[train_idx], y[test_idx]


# Sigmoid 

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))


# Q2.1 

def logistic_bce_loss(y, y_hat):
    eps = 1e-12
    return -np.mean(y * np.log(y_hat + eps) + (1 - y) * np.log(1 - y_hat + eps))


def train_bgd(X_train, y_train, lr=1e-3, epochs=500, class_weights=None):
    """
    Batch Gradient Descent logistic regression.
    class_weights: dict {0: w0, 1: w1} – if None, all samples weighted equally.
    Returns: w, b, loss_history
    """
    N, M = X_train.shape
    w = np.zeros(M, dtype=np.float64)
    b = 0.0

    # Sample-level weights
    if class_weights is None:
        sample_w = np.ones(N, dtype=np.float64)
    else:
        sample_w = np.where(y_train == 1, class_weights[1], class_weights[0]).astype(np.float64)
    sample_w /= sample_w.sum()         # normalise so loss scale is comparable

    loss_history = []
    for epoch in range(epochs):
        z     = X_train @ w + b
        y_hat = sigmoid(z)

        # Weighted BCE loss
        eps   = 1e-12
        loss  = -np.sum(sample_w * (y_train * np.log(y_hat + eps) +
                                    (1 - y_train) * np.log(1 - y_hat + eps)))
        loss_history.append(loss)

        # Gradients
        err    = sample_w * (y_hat - y_train)
        dw     = X_train.T @ err
        db     = err.sum()

        w -= lr * dw
        b -= lr * db

    return w, b, loss_history


def question_2_1(X_train, y_train, X_test, y_test, output_dir):
    print("\n===== Question 2.1 – Standard BGD =====")
    w, b, loss_hist = train_bgd(X_train, y_train, lr=1e-3, epochs=500)

    plt.figure(figsize=(8, 4))
    plt.plot(loss_hist, color='steelblue')
    plt.xlabel('Epoch'); plt.ylabel('Weighted BCE Loss')
    plt.title('Training Loss – Standard BGD')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q2_1_loss.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Final training loss: {loss_hist[-1]:.5f}")
    print(f"  Saved: q2_1_loss.png")
    return w, b


#  Q2.2 

def compute_class_weights(y_train):
    """Inverse-frequency class weights."""
    n_total = len(y_train)
    n_pos   = y_train.sum()
    n_neg   = n_total - n_pos
    w0 = n_total / (2 * n_neg)
    w1 = n_total / (2 * n_pos)
    print(f"  Class weights → 0: {w0:.4f}, 1: {w1:.4f}")
    return {0: w0, 1: w1}


def question_2_2(X_train, y_train, X_test, y_test, output_dir):
    print("\n===== Question 2.2 – Weighted BGD =====")
    cw = compute_class_weights(y_train)
    w, b, loss_hist = train_bgd(X_train, y_train, lr=1e-3, epochs=500, class_weights=cw)

    plt.figure(figsize=(8, 4))
    plt.plot(loss_hist, color='tomato')
    plt.xlabel('Epoch'); plt.ylabel('Weighted BCE Loss')
    plt.title('Training Loss – Weighted BGD')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q2_2_loss_weighted.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Final training loss: {loss_hist[-1]:.5f}")
    print(f"  Saved: q2_2_loss_weighted.png")
    return w, b


#  Q2.3 

def predict_proba(X, w, b):
    return sigmoid(X @ w + b)


def precision_recall_curve(y_true, y_scores):
    """
    Compute precision and recall at every distinct threshold in y_scores.
    Returns arrays sorted by ascending recall.
    """
    thresholds = np.sort(np.unique(y_scores))[::-1]   # high → low

    precisions = []
    recalls    = []

    for thr in thresholds:
        y_pred = (y_scores >= thr).astype(int)
        tp = np.sum((y_pred == 1) & (y_true == 1))
        fp = np.sum((y_pred == 1) & (y_true == 0))
        fn = np.sum((y_pred == 0) & (y_true == 1))

        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        precisions.append(prec)
        recalls.append(rec)

    # Add (0, 1) sentinel to anchor the curve at recall=0
    recalls    = np.array([0.0] + recalls)
    precisions = np.array([1.0] + precisions)

    # Sort by recall ascending for trapezoidal integration
    order = np.argsort(recalls)
    recalls    = recalls[order]
    precisions = precisions[order]
    return precisions, recalls


def auprc_trapezoid(precisions, recalls):
    """Trapezoidal rule AUPRC."""
    area = 0.0
    for i in range(1, len(recalls)):
        area += 0.5 * (recalls[i] - recalls[i-1]) * (precisions[i] + precisions[i-1])
    return area


def question_2_3(X_test, y_test, w_std, b_std, w_wgt, b_wgt, output_dir):
    print("\n===== Question 2.3 – AUPRC =====")

    scores_std = predict_proba(X_test, w_std, b_std)
    scores_wgt = predict_proba(X_test, w_wgt, b_wgt)

    prec_std, rec_std = precision_recall_curve(y_test, scores_std)
    prec_wgt, rec_wgt = precision_recall_curve(y_test, scores_wgt)

    auprc_std = auprc_trapezoid(prec_std, rec_std)
    auprc_wgt = auprc_trapezoid(prec_wgt, rec_wgt)

    print(f"  Standard BGD  AUPRC = {auprc_std:.4f}")
    print(f"  Weighted BGD  AUPRC = {auprc_wgt:.4f}")

    # Baseline (random classifier)
    baseline = y_test.mean()

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(rec_std, prec_std, label=f'Standard BGD (AUPRC={auprc_std:.3f})',
            color='steelblue', linewidth=2)
    ax.plot(rec_wgt, prec_wgt, label=f'Weighted BGD (AUPRC={auprc_wgt:.3f})',
            color='tomato', linewidth=2)
    ax.axhline(y=baseline, color='gray', linestyle='--', label=f'Random (AUPRC≈{baseline:.3f})')
    ax.set_xlabel('Recall')
    ax.set_ylabel('Precision')
    ax.set_title('Precision-Recall Curves')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.set_xlim([0, 1]); ax.set_ylim([0, 1.05])
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q2_3_pr_curves.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: q2_3_pr_curves.png")

    return auprc_std, auprc_wgt


#  Main 

def main(data_dir, output_dir='outputs'):
    os.makedirs(output_dir, exist_ok=True)

    X, y = load_data(data_dir)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_frac=0.30)
    print(f"Train: {X_train.shape}, Test: {X_test.shape}")
    print(f"Train class dist: {np.bincount(y_train.astype(int))}")
    print(f"Test  class dist: {np.bincount(y_test.astype(int))}")

    X_train, X_test = minmax_normalize(X_train, X_test)

    w_std, b_std = question_2_1(X_train, y_train, X_test, y_test, output_dir)
    w_wgt, b_wgt = question_2_2(X_train, y_train, X_test, y_test, output_dir)
    question_2_3(X_test, y_test, w_std, b_std, w_wgt, b_wgt, output_dir)

    print("\nAll Q2 outputs saved to:", output_dir)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python logistic.py <path_to_gene_data_folder>")
        sys.exit(1)
    main(sys.argv[1], output_dir='../outputs')
