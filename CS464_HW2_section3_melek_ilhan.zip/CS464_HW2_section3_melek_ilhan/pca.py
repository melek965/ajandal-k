"""
CS464 HW2 - Question 1: PCA Analysis on FFHQ Face Images
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os
import sys
from PIL import Image


# Data Loading 

def load_images(dataset_path, n=10000):
    """Load first n images from dataset_path, resize to 64x64 and flatten."""
    all_files = sorted([
        f for f in os.listdir(dataset_path)
        if f.lower().endswith(('.png', '.jpg', '.jpeg'))
    ])
    image_files = all_files[:n]

    images = []
    for fname in image_files:
        img = Image.open(os.path.join(dataset_path, fname)).convert('RGB')
        img = img.resize((64, 64), Image.BILINEAR)
        arr = np.asarray(img).reshape(-1, 3).astype(np.float32)
        images.append(arr)

    X = np.stack(images)          # (10000, 4096, 3)
    print(f"Dataset shape: {X.shape}")
    return X


# PCA Core 

def pca(Xi, n_components=10):
    """
    Perform PCA on Xi (N x D).
    Returns: mean, eigenvectors (sorted, D x k), eigenvalues (k,), all eigenvalues.
    """
    mean = Xi.mean(axis=0)              # (D,)
    Xc   = Xi - mean                   # mean-centred

    cov  = (Xc.T @ Xc) / (Xi.shape[0] - 1)   # (D x D)

    eigvals_all, eigvecs_all = np.linalg.eig(cov)
    eigvals_all = eigvals_all.real
    eigvecs_all = eigvecs_all.real

    # Sort descending
    idx        = np.argsort(eigvals_all)[::-1]
    eigvals_all = eigvals_all[idx]
    eigvecs_all = eigvecs_all[:, idx]

    eigvecs = eigvecs_all[:, :n_components]    # (D x k)
    eigvals = eigvals_all[:n_components]       # (k,)

    return mean, eigvecs, eigvals, eigvals_all


def compute_pve(eigvals, eigvals_all):
    """Proportion of Variance Explained per component."""
    total = eigvals_all.sum()
    pve   = eigvals / total
    return pve


# Q1.1

def question_1_1(X, output_dir):
    """PCA on each channel, report PVE for first 10 PCs."""
    channel_names = ['Red', 'Green', 'Blue']
    results = {}

    print("\n===== Question 1.1 =====")
    for i, ch in enumerate(channel_names):
        Xi = X[:, :, i]                              # (10000 x 4096)
        mean, eigvecs, eigvals, eigvals_all = pca(Xi, n_components=10)
        pve = compute_pve(eigvals, eigvals_all)

        print(f"\n--- {ch} channel ---")
        for j, (v, p) in enumerate(zip(eigvals, pve)):
            print(f"  PC{j+1:2d}: eigenvalue={v:10.2f}  PVE={p*100:.3f}%")
        print(f"  Cumulative PVE (10 PCs): {pve.sum()*100:.3f}%")

        results[ch] = {
            'mean': mean, 'eigvecs': eigvecs,
            'eigvals': eigvals, 'eigvals_all': eigvals_all, 'pve': pve
        }

    # Minimum PCs for 70% PVE in every channel
    print("\n--- Minimum PCs for >=70% PVE in ALL channels ---")
    for k in range(1, 4097):
        all_ok = True
        for i, ch in enumerate(channel_names):
            Xi = X[:, :, i]
            _, _, _, eigvals_all = pca(Xi, n_components=k) if k <= 10 else \
                (None, None, None, results[ch]['eigvals_all'])
            cumulative = results[ch]['eigvals_all'][:k].sum() / \
                         results[ch]['eigvals_all'].sum()
            if cumulative < 0.70:
                all_ok = False
                break
        if all_ok:
            print(f"  Minimum k = {k} PCs for >=70% PVE in all channels")
            break

    # Save PVE bar chart
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    for ax, ch in zip(axes, channel_names):
        pve = results[ch]['pve']
        ax.bar(range(1, 11), pve * 100, color={'Red':'tomato','Green':'seagreen','Blue':'steelblue'}[ch])
        ax.set_title(f'{ch} Channel PVE')
        ax.set_xlabel('Principal Component')
        ax.set_ylabel('PVE (%)')
        ax.set_xticks(range(1, 11))
        for j, v in enumerate(pve):
            ax.text(j+1, v*100+0.1, f'{v*100:.1f}%', ha='center', fontsize=7)
    plt.suptitle('Proportion of Variance Explained – First 10 PCs', fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q1_1_pve.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: q1_1_pve.png")

    return results


#  Q1.2

def minmax_scale(arr):
    mn, mx = arr.min(), arr.max()
    if mx == mn:
        return np.zeros_like(arr)
    return (arr - mn) / (mx - mn)


def question_1_2(results, output_dir):
    """Visualise the first 10 eigenvectors as RGB images."""
    print("\n===== Question 1.2 =====")

    channel_names = ['Red', 'Green', 'Blue']
    all_evecs = {}
    for ch in channel_names:
        all_evecs[ch] = results[ch]['eigvecs']   # (4096 x 10)

    fig, axes = plt.subplots(2, 5, figsize=(15, 7))
    axes = axes.flatten()

    for k in range(10):
        rgb_channels = []
        for ch in channel_names:
            pc = all_evecs[ch][:, k]        # (4096,)
            pc_img = pc.reshape(64, 64)     # (64 x 64)
            pc_scaled = minmax_scale(pc_img)
            rgb_channels.append(pc_scaled)

        rgb_image = np.stack(rgb_channels, axis=-1)   # (64 x 64 x 3)
        axes[k].imshow(rgb_image)
        axes[k].set_title(f'PC {k+1}', fontsize=11)
        axes[k].axis('off')

    plt.suptitle('First 10 Principal Components as RGB Images', fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q1_2_eigenvectors.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: q1_2_eigenvectors.png")


#  Q1.3 

def reconstruct(Xi_centered, mean, eigvecs_k):
    """
    Project Xi_centered onto eigvecs_k and reconstruct.
    Xi_centered: (D,)   eigvecs_k: (D x k)
    Returns: reconstructed (D,) in original scale.
    """
    coords  = Xi_centered @ eigvecs_k          # (k,)
    recon   = coords @ eigvecs_k.T             # (D,)
    return recon + mean


def question_1_3(X, results, output_dir, img_idx=200):
    """Reconstruct image at img_idx for k in {1,50,250,500,1000,4096}."""
    print(f"\n===== Question 1.3 – Image index {img_idx} =====")
    ks = [1, 50, 250, 500, 1000, 4096]
    channel_names = ['Red', 'Green', 'Blue']

    fig, axes = plt.subplots(1, len(ks)+1, figsize=(3*(len(ks)+1), 3.5))

    # Original
    orig = X[img_idx].astype(np.float32)    # (4096 x 3)
    orig_img = orig.reshape(64, 64, 3).clip(0, 255).astype(np.uint8)
    axes[0].imshow(orig_img)
    axes[0].set_title('Original', fontsize=10)
    axes[0].axis('off')

    for ax, k in zip(axes[1:], ks):
        recon_channels = []
        for i, ch in enumerate(channel_names):
            mean   = results[ch]['mean']
            # Get k eigenvectors (may need full PCA if k > 10)
            if k <= 10:
                eigvecs_k = results[ch]['eigvecs'][:, :k]
            else:
                eigvecs_k = results[ch]['eigvecs_full'][:, :k]
            xi_c = orig[:, i] - mean
            r = reconstruct(xi_c, mean, eigvecs_k)
            recon_channels.append(r)

        recon_img = np.stack(recon_channels, axis=-1).reshape(64, 64, 3)
        recon_img = np.clip(recon_img, 0, 255).astype(np.uint8)
        ax.imshow(recon_img)
        ax.set_title(f'k={k}', fontsize=10)
        ax.axis('off')

    plt.suptitle(f'Image Reconstruction (Index {img_idx})', fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q1_3_reconstruction.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: q1_3_reconstruction.png")


#  Q1.4 

def question_1_4(X, results, output_dir, img_idx=200):
    """PCA denoising."""
    print(f"\n===== Question 1.4 – Denoising (Image {img_idx}) =====")
    ks            = [10, 50, 100, 250, 500]
    channel_names = ['Red', 'Green', 'Blue']

    orig    = X[img_idx].astype(np.float32)    # (4096 x 3)
    orig_img = orig.reshape(64, 64, 3).clip(0, 255).astype(np.uint8)

    np.random.seed(42)
    noise        = np.random.normal(0, 25, orig.shape).astype(np.float32)
    noisy        = np.clip(orig + noise, 0, 255)
    noisy_img    = noisy.reshape(64, 64, 3).astype(np.uint8)

    # Step 1: show original vs noisy 
    fig, axes = plt.subplots(1, 2, figsize=(7, 3.5))
    axes[0].imshow(orig_img); axes[0].set_title('Original'); axes[0].axis('off')
    axes[1].imshow(noisy_img); axes[1].set_title('Noisy (σ=25)'); axes[1].axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q1_4_noisy.png'), dpi=150, bbox_inches='tight')
    plt.close()

    # Step 2: denoise with k components 
    fig, axes = plt.subplots(1, len(ks)+1, figsize=(3*(len(ks)+1), 3.5))
    axes[0].imshow(orig_img); axes[0].set_title('Original'); axes[0].axis('off')

    mse_per_k = {ch: [] for ch in channel_names}

    for ax, k in zip(axes[1:], ks):
        denoised_channels = []
        for i, ch in enumerate(channel_names):
            mean      = results[ch]['mean']
            eigvecs_k = results[ch]['eigvecs_full'][:, :k]
            noisy_c   = noisy[:, i] - mean
            d = reconstruct(noisy_c, mean, eigvecs_k)
            denoised_channels.append(d)

            mse = np.mean((d - orig[:, i]) ** 2)
            mse_per_k[ch].append(mse)

        denoised_img = np.stack(denoised_channels, axis=-1).reshape(64, 64, 3)
        denoised_img = np.clip(denoised_img, 0, 255).astype(np.uint8)
        ax.imshow(denoised_img)
        ax.set_title(f'k={k}', fontsize=10)
        ax.axis('off')

    plt.suptitle('Denoised Images (PCA)', fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q1_4_denoised.png'), dpi=150, bbox_inches='tight')
    plt.close()

    # Step 3: MSE vs k 
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = {'Red': 'tomato', 'Green': 'seagreen', 'Blue': 'steelblue'}
    for ch in channel_names:
        ax.plot(ks, mse_per_k[ch], marker='o', label=ch, color=colors[ch])
    ax.set_xlabel('k (number of PCs)')
    ax.set_ylabel('MSE')
    ax.set_title('MSE vs. k for PCA Denoising')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'q1_4_mse.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print("  Saved: q1_4_noisy.png, q1_4_denoised.png, q1_4_mse.png")

    for ch in channel_names:
        for k, mse in zip(ks, mse_per_k[ch]):
            print(f"  {ch} k={k:4d}  MSE={mse:.4f}")


#  Full PCA helper

def full_pca_all_components(X, results):
    """Compute PCA with ALL components for each channel (needed for k>10)."""
    channel_names = ['Red', 'Green', 'Blue']
    for i, ch in enumerate(channel_names):
        Xi   = X[:, :, i]
        mean = results[ch]['mean']
        Xc   = Xi - mean
        cov  = (Xc.T @ Xc) / (Xi.shape[0] - 1)
        eigvals_all, eigvecs_all = np.linalg.eig(cov)
        eigvals_all = eigvals_all.real
        eigvecs_all = eigvecs_all.real
        idx = np.argsort(eigvals_all)[::-1]
        results[ch]['eigvecs_full'] = eigvecs_all[:, idx]   # (4096 x 4096)
    return results


#  Main 

def main(dataset_path, output_dir='outputs'):
    os.makedirs(output_dir, exist_ok=True)

    print("Loading images...")
    X = load_images(dataset_path)

    print("\nRunning Q1.1 ...")
    results = question_1_1(X, output_dir)

    print("\nComputing full PCA (all components) – this may take a while...")
    results = full_pca_all_components(X, results)

    print("\nRunning Q1.2 ...")
    question_1_2(results, output_dir)

    print("\nRunning Q1.3 ...")
    question_1_3(X, results, output_dir, img_idx=200)

    print("\nRunning Q1.4 ...")
    question_1_4(X, results, output_dir, img_idx=200)

    print("\nAll Q1 outputs saved to:", output_dir)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python pca.py <path_to_ffhq256_folder>")
        sys.exit(1)
    main(sys.argv[1], output_dir='../outputs')
